# High School System — local setup

This package contains the existing school-system frontend, Express API, and SQL Server database script.
The backend is configured for Windows Integrated Authentication for the default SQL Server instance `Maqhoboza`.

## Important
- The archive intentionally excludes your local `.env` and `node_modules` so secrets and machine-specific packages are not distributed.
- This is a local development build. Before using it with real learners, review privacy, access permissions, backups, HTTPS, and deployment security.
- Do not publish real learner/parent records or commit `.env` to source control.
- The browser interface and database connection must be tested on the computer where SQL Server is installed; this package cannot verify your local Windows account permissions or SQL Server network settings.

## Database
1. Open SQL Server Management Studio and run `database/01-create-database.sql`.
2. The script creates/uses `HighSchoolSystem` and its core tables.
3. The Windows account running Node.js must have permission to connect and read/write the required tables.

## Backend
1. Install Node.js LTS.
2. Open a terminal in `backend`.
3. Copy `.env.example` to `.env`.
4. Set `JWT_SECRET` to a long random private value. Keep it secret.
5. Install dependencies with `npm install`.
6. Start the API with `npm start`.
7. Open `http://localhost:3000` in your browser. Health check: `http://localhost:3000/api/health`.

The server uses the Windows identity of the account running Node.js for SQL Server authentication. It does not use `DB_USER` or `DB_PASSWORD`.

## First administrator
The database script does not create a default administrator account. Create the first admin through a controlled database seed/setup procedure using a bcrypt password hash, or add a one-time bootstrap route before starting the system. Do not expose an open public admin-registration endpoint.

## Integration status
The supplied pages and scripts were created at different stages. This package aligns the login request with the backend and serves the frontend through Express, but it has not been end-to-end tested against your local SQL Server instance. Some pages may still need their API calls and database-backed workflows reconciled before it can be treated as production-ready.
