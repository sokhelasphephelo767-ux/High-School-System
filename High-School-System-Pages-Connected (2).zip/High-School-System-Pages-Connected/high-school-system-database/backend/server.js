require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const sql = require("mssql/msnodesqlv8");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve the website from the same local server as the API.
app.use(express.static(path.join(__dirname, "../frontend")));

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME";


const dbConfig = {
  connectionString:
    `Driver={ODBC Driver 18 for SQL Server};` +
    `Server=${process.env.DB_SERVER || "Maqhoboza"};` +
    `Database=${process.env.DB_NAME || "HighSchoolSystem"};` +
    `Trusted_Connection=Yes;` +
    `Encrypt=Yes;` +
    `TrustServerCertificate=Yes;`
};
let pool;
async function db() {
  if (!pool) pool = await sql.connect(dbConfig);
  return pool;
}

function signUser(u) {
  return jwt.sign(
    {
      userId: u.UserID,
      systemUserID: u.SystemUserID,
      role: u.Role,
      fullName: u.FullName,
    },
    JWT_SECRET,
    { expiresIn: "8h" },
  );
}
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token)
    return res.status(401).json({ message: "Authentication required." });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res
      .status(401)
      .json({ message: "Session expired or token is invalid." });
  }
}
function roles(...allowed) {
  return (req, res, next) =>
    allowed.includes(req.user.role)
      ? next()
      : res
          .status(403)
          .json({ message: "You do not have permission for this action." });
}
function nextSystemID(prefix, rows) {
  let n = 1;
  const used = new Set(
    rows.map((x) => String(x.SystemUserID || "").toUpperCase()),
  );
  while (used.has(prefix + String(n).padStart(3, "0"))) n++;
  return prefix + String(n).padStart(3, "0");
}
function prefix(role) {
  return (
    { Administrator: "ADM", Teacher: "TCH", Parent: "PAR", Learner: "LRN" }[
      role
    ] || "USR"
  );
}
function normalizeRoleName(role) {
  const value = String(role || "").trim();
  const aliases = {
    admin: "Administrator",
    administrator: "Administrator",
    teacher: "Teacher",
    parent: "Parent",
    learner: "Learner",
  };
  return aliases[value.toLowerCase()] || value;
}
function cleanUser(u) {
  return {
    userID: u.SystemUserID,
    systemUserID: u.SystemUserID,
    fullName: u.FullName,
    email: u.Email,
    phone: u.Phone,
    role: u.Role,
    status: u.Status,
  };
}

const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) =>
    cb(
      null,
      Date.now() + "-" + file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_"),
    ),
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

app.get("/api/health", async (_, res) => {
  try {
    await db();
    res.json({ ok: true, database: "connected" });
  } catch (e) {
    res
      .status(500)
      .json({ ok: false, database: "disconnected", error: e.message });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const userID = req.body.userID || req.body.username;
    const { password } = req.body;
    const normalizedRole = normalizeRoleName(req.body.role);
    if (!userID || !password || !normalizedRole)
      return res
        .status(400)
        .json({ message: "User ID, password and role are required." });
    const p = await db();
    const r = await p
      .request()
      .input("id", sql.VarChar(20), String(userID).toUpperCase())
      .query(
        `SELECT TOP 1 * FROM Users WHERE SystemUserID=@id AND Status='Active'`,
      );
    const u = r.recordset[0];
    if (
      !u ||
      normalizeRoleName(u.Role) !== normalizedRole ||
      !(await bcrypt.compare(password, u.PasswordHash))
    )
      return res
        .status(401)
        .json({ message: "Incorrect User ID, password or role." });
    res.json({ token: signUser(u), user: cleanUser(u) });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get(
  "/api/dashboard/stats",
  auth,
  roles("Administrator"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p.request().query("SELECT * FROM vw_DashboardStats");
      res.json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get("/api/users", auth, roles("Administrator"), async (req, res) => {
  try {
    const p = await db();
    const r = await p
      .request()
      .query(
        `SELECT UserID,SystemUserID,FullName,Email,Phone,Role,Status,CreatedAt FROM Users ORDER BY CreatedAt DESC`,
      );
    res.json(r.recordset.map(cleanUser));
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.post("/api/users", auth, roles("Administrator"), async (req, res) => {
  try {
    const { fullName, email, phone, role, password } = req.body;
    if (!fullName || !email || !role || !password)
      return res
        .status(400)
        .json({ message: "Full name, email, role and password are required." });
    if (!["Administrator", "Teacher", "Parent", "Learner"].includes(role))
      return res.status(400).json({ message: "Invalid role." });
    const p = await db();
    const existing = await p
      .request()
      .input("email", sql.NVarChar(255), email)
      .query("SELECT UserID FROM Users WHERE Email=@email");
    if (existing.recordset.length)
      return res.status(409).json({ message: "Email already exists." });
    const all = await p.request().query("SELECT SystemUserID FROM Users");
    const systemUserID = nextSystemID(prefix(role), all.recordset);
    const hash = await bcrypt.hash(password, 12);
    const r = await p
      .request()
      .input("sid", sql.VarChar(20), systemUserID)
      .input("name", sql.NVarChar(150), fullName)
      .input("email", sql.NVarChar(255), email)
      .input("phone", sql.NVarChar(30), phone || null)
      .input("hash", sql.NVarChar(255), hash)
      .input("role", sql.VarChar(20), role)
      .query(
        `INSERT INTO Users(SystemUserID,FullName,Email,Phone,PasswordHash,Role) OUTPUT INSERTED.* VALUES(@sid,@name,@email,@phone,@hash,@role)`,
      );
    res
      .status(201)
      .json({
        message: "User created successfully.",
        user: cleanUser(r.recordset[0]),
      });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.delete(
  "/api/users/:systemID",
  auth,
  roles("Administrator"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("sid", sql.VarChar(20), req.params.systemID)
        .query("DELETE FROM Users WHERE SystemUserID=@sid");
      if (!r.rowsAffected[0]) {
        return res.status(404).json({ message: "User not found." });
      }
      res.json({ message: "User deleted." });
    } catch (e) {
      res.status(500).json({
        message:
          "Cannot delete this user because another record is linked to the account. Deactivate it instead.",
      });
    }
  },
);

app.post("/api/applications", async (req, res) => {
  try {
    const x = req.body;
    const required = [
      "learnerName",
      "dateOfBirth",
      "grade",
      "parentName",
      "idNumber",
      "parentPhone",
      "parentEmail",
      "address",
      "city",
      "postalCode",
      "emergencyName",
      "emergencyPhone",
      "relationship",
    ];
    if (required.some((k) => !String(x[k] || "").trim()))
      return res
        .status(400)
        .json({ message: "Please complete all required fields." });
    const p = await db();
    const r = await p
      .request()
      .input("learnerName", sql.NVarChar(150), x.learnerName)
      .input("dob", sql.Date, x.dateOfBirth)
      .input("gender", sql.VarChar(20), x.gender || null)
      .input("grade", sql.NVarChar(20), x.grade)
      .input("previousSchool", sql.NVarChar(200), x.previousSchool || null)
      .input("parentName", sql.NVarChar(150), x.parentName)
      .input("idNumber", sql.NVarChar(50), x.idNumber)
      .input("phone", sql.NVarChar(30), x.parentPhone)
      .input("email", sql.NVarChar(255), x.parentEmail)
      .input("address", sql.NVarChar(300), x.address)
      .input("city", sql.NVarChar(100), x.city)
      .input("postal", sql.NVarChar(20), x.postalCode)
      .input("emergencyName", sql.NVarChar(150), x.emergencyName)
      .input("emergencyPhone", sql.NVarChar(30), x.emergencyPhone)
      .input("relationship", sql.NVarChar(80), x.relationship)
      .input("allergies", sql.NVarChar(500), x.allergies || null)
      .input("medical", sql.NVarChar(1000), x.medical || null)
      .input("birth", sql.NVarChar(255), x.birthCertificate || null)
      .input("residence", sql.NVarChar(255), x.residence || null)
      .input("transfer", sql.NVarChar(255), x.transferLetter || null)
      .input("parentID", sql.NVarChar(255), x.parentID || null)
      .input("medicalReport", sql.NVarChar(255), x.medicalReport || null)
      .query(`INSERT INTO AdmissionApplications
      (LearnerName,DateOfBirth,Gender,Grade,PreviousSchool,ParentName,IDNumber,ParentPhone,ParentEmail,Address,City,PostalCode,EmergencyName,EmergencyPhone,Relationship,Allergies,Medical,BirthCertificateFile,ResidenceFile,TransferLetterFile,ParentIDFile,MedicalReportFile)
      OUTPUT INSERTED.ApplicationID,INSERTED.Status,INSERTED.SubmittedAt
      VALUES(@learnerName,@dob,@gender,@grade,@previousSchool,@parentName,@idNumber,@phone,@email,@address,@city,@postal,@emergencyName,@emergencyPhone,@relationship,@allergies,@medical,@birth,@residence,@transfer,@parentID,@medicalReport)`);
    res
      .status(201)
      .json({
        message: "Application submitted successfully.",
        application: r.recordset[0],
      });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get("/api/applications", auth, roles("Administrator"), async (req, res) => {
  try {
    const p = await db();
    const r = await p
      .request()
      .query(`SELECT * FROM AdmissionApplications ORDER BY SubmittedAt DESC`);
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get(
  "/api/applications/:id",
  auth,
  roles("Administrator"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("id", sql.Int, Number(req.params.id))
        .query("SELECT * FROM AdmissionApplications WHERE ApplicationID=@id");
      if (!r.recordset[0])
        return res.status(404).json({ message: "Application not found." });
      res.json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/applications/:id/approve",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const transaction = new sql.Transaction(await db());
    try {
      await transaction.begin();
      const request = () => new sql.Request(transaction);
      const a = (
        await request()
          .input("id", sql.Int, Number(req.params.id))
          .query("SELECT * FROM AdmissionApplications WHERE ApplicationID=@id")
      ).recordset[0];
      if (!a) {
        await transaction.rollback();
        return res.status(404).json({ message: "Application not found." });
      }
      if (a.Status === "Approved") {
        await transaction.rollback();
        return res
          .status(409)
          .json({ message: "Application already approved." });
      }
      const users = (await request().query("SELECT SystemUserID FROM Users"))
        .recordset;
      const parentID = nextSystemID("PAR", users);
      const temporaryPassword =
        "Parent@" + Math.floor(1000 + Math.random() * 9000);
      const hash = await bcrypt.hash(temporaryPassword, 12);
      const u = (
        await request()
          .input("sid", sql.VarChar(20), parentID)
          .input("name", sql.NVarChar(150), a.ParentName)
          .input("email", sql.NVarChar(255), a.ParentEmail)
          .input("phone", sql.NVarChar(30), a.ParentPhone)
          .input("hash", sql.NVarChar(255), hash)
          .query(
            `INSERT INTO Users(SystemUserID,FullName,Email,Phone,PasswordHash,Role) OUTPUT INSERTED.UserID VALUES(@sid,@name,@email,@phone,@hash,'Parent')`,
          )
      ).recordset[0];
      await request()
        .input("app", sql.Int, a.ApplicationID)
        .input("parentUser", sql.Int, u.UserID)
        .input("reviewer", sql.Int, req.user.userId)
        .query(
          `UPDATE AdmissionApplications SET Status='Approved',ParentUserID=@parentUser,ReviewedAt=SYSUTCDATETIME(),ReviewedBy=@reviewer WHERE ApplicationID=@app`,
        );
      await request()
        .input("app", sql.Int, a.ApplicationID)
        .input("parent", sql.Int, u.UserID)
        .input("name", sql.NVarChar(150), a.LearnerName)
        .input("dob", sql.Date, a.DateOfBirth)
        .input("gender", sql.VarChar(20), a.Gender)
        .input("grade", sql.NVarChar(20), a.Grade)
        .input("prev", sql.NVarChar(200), a.PreviousSchool)
        .query(`INSERT INTO Learners(ApplicationID,FullName,DateOfBirth,Gender,Grade,PreviousSchool,ParentUserID)
      VALUES(@app,@name,@dob,@gender,@grade,@prev,@parent)`);
      await transaction.commit();
      res.json({
        message: "Application approved and parent/learner created.",
        userID: parentID,
        temporaryPassword,
      });
    } catch (e) {
      try {
        await transaction.rollback();
      } catch {}
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/applications/:id/reject",
  auth,
  roles("Administrator"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("id", sql.Int, Number(req.params.id))
        .input("reviewer", sql.Int, req.user.userId)
        .query(
          `UPDATE AdmissionApplications SET Status='Rejected',ReviewedAt=SYSUTCDATETIME(),ReviewedBy=@reviewer WHERE ApplicationID=@id AND Status='Pending'`,
        );
      if (!r.rowsAffected[0])
        return res
          .status(404)
          .json({ message: "Pending application not found." });
      res.json({ message: "Application rejected." });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/learners",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
  try {
    const p = await db();
    const query = p.request();
    let sqlText = `SELECT l.*,u.SystemUserID,u.FullName AS UserFullName,u.Email AS ParentEmail,u.Phone AS ParentPhone,c.ClassName FROM Learners l LEFT JOIN Users u ON u.UserID=l.ParentUserID LEFT JOIN Classes c ON c.ClassID=l.ClassID WHERE l.Status='Active'`;
    if (req.user.role === "Parent") {
      sqlText += " AND l.ParentUserID=@parentID";
      query.input("parentID", sql.Int, req.user.userId);
    }
    sqlText += " ORDER BY l.FullName";
    const r = await query.query(sqlText);
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
  },
);

app.get(
  "/api/learners/:id",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const learnerID = Number(req.params.id);
    if (!Number.isInteger(learnerID) || learnerID < 1) {
      return res.status(400).json({ message: "Invalid learner ID." });
    }

    try {
      const p = await db();
      const result = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .query(`
          SELECT learner.*, learnerUser.SystemUserID,
            parent.FullName AS ParentName, parent.Phone AS Phone,
            schoolClass.ClassName
          FROM dbo.Learners AS learner
          LEFT JOIN dbo.Users AS learnerUser
            ON learnerUser.UserID = learner.UserID
          LEFT JOIN dbo.Users AS parent
            ON parent.UserID = learner.ParentUserID
          LEFT JOIN dbo.Classes AS schoolClass
            ON schoolClass.ClassID = learner.ClassID
          WHERE learner.LearnerID = @learnerID
            AND learner.Status = 'Active';
        `);

      if (!result.recordset.length) {
        return res.status(404).json({ message: "Learner not found." });
      }

      res.json({ learner: result.recordset[0] });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.put(
  "/api/learners/:id/class",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const learnerID = Number(req.params.id);
    const classID = Number(req.body.classID);

    if (!Number.isInteger(learnerID) || learnerID < 1) {
      return res.status(400).json({ message: "Invalid learner ID." });
    }
    if (!Number.isInteger(classID) || classID < 1) {
      return res.status(400).json({ message: "Please choose a valid class." });
    }

    try {
      const p = await db();
      const result = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .input("classID", sql.Int, classID).query(`
          UPDATE learner
          SET ClassID = @classID
          FROM dbo.Learners AS learner
          INNER JOIN dbo.Classes AS schoolClass
            ON schoolClass.ClassID = @classID
            AND schoolClass.Grade = learner.Grade
          WHERE learner.LearnerID = @learnerID
            AND learner.Status = 'Active';

          SELECT @@ROWCOUNT AS UpdatedRows;
        `);

      if (!result.recordset?.[0]?.UpdatedRows) {
        return res.status(404).json({
          message: "Active learner or matching-grade class not found.",
        });
      }

      res.json({ message: "Learner class assigned successfully." });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get("/api/teachers", auth, async (req, res) => {
  try {
    const p = await db();
    const r = await p
      .request()
      .query(
        `SELECT UserID,SystemUserID,FullName,Email,Phone,Status FROM Users WHERE Role='Teacher' ORDER BY FullName`,
      );
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get("/api/parents", auth, roles("Administrator"), async (req, res) => {
  try {
    const p = await db();
    const r = await p
      .request()
      .query(
        `SELECT u.UserID,u.SystemUserID,u.FullName,u.Email,u.Phone,u.Status, l.FullName AS LearnerName,l.Grade FROM Users u LEFT JOIN Learners l ON l.ParentUserID=u.UserID WHERE u.Role='Parent' ORDER BY u.FullName`,
      );
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

app.get("/api/subjects", auth, async (req, res) => {
  try {
    const p = await db();
    const r = await p
      .request()
      .query("SELECT * FROM Subjects ORDER BY SubjectName");
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});
app.post(
  "/api/subjects",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("name", sql.NVarChar(100), req.body.name)
        .input("code", sql.VarChar(20), req.body.code)
        .input("grade", sql.NVarChar(20), req.body.grade || null)
        .query(
          "INSERT INTO Subjects(SubjectName,SubjectCode,Grade) OUTPUT INSERTED.* VALUES(@name,@code,@grade)",
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/teacher-subjects",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    try {
      const p = await db();
      const result = await p
        .request()
        .input("teacherID", sql.Int, req.user.userId)
        .input("isAdmin", sql.Bit, req.user.role === "Administrator")
        .query(`
          SELECT ts.TeacherSubjectID, ts.TeacherID, teacher.FullName AS TeacherName,
            subject.SubjectID, subject.SubjectName, subject.SubjectCode,
            class.ClassID, class.ClassName
          FROM dbo.TeacherSubjects AS ts
          INNER JOIN dbo.Users AS teacher ON teacher.UserID=ts.TeacherID
          INNER JOIN dbo.Subjects AS subject ON subject.SubjectID=ts.SubjectID
          LEFT JOIN dbo.Classes AS class ON class.ClassID=ts.ClassID
          WHERE @isAdmin=1 OR ts.TeacherID=@teacherID
          ORDER BY teacher.FullName, subject.SubjectName, class.ClassName;
        `);
      res.json(result.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/teacher-subjects",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const teacherID = Number(req.body.teacherID);
    const subjectID = Number(req.body.subjectID);
    const classID =
      req.body.classID === null || req.body.classID === ""
        ? null
        : Number(req.body.classID);

    if (!Number.isInteger(teacherID) || teacherID < 1) {
      return res.status(400).json({ message: "Choose a valid teacher." });
    }
    if (!Number.isInteger(subjectID) || subjectID < 1) {
      return res.status(400).json({ message: "Choose a valid subject." });
    }
    if (classID !== null && (!Number.isInteger(classID) || classID < 1)) {
      return res.status(400).json({ message: "Choose a valid class." });
    }

    try {
      const p = await db();
      const teacher = await p
        .request()
        .input("teacherID", sql.Int, teacherID)
        .query(
          "SELECT UserID FROM dbo.Users WHERE UserID=@teacherID AND Role='Teacher' AND Status='Active'",
        );
      if (!teacher.recordset.length) {
        return res.status(404).json({ message: "Active teacher not found." });
      }

      const subject = await p
        .request()
        .input("subjectID", sql.Int, subjectID)
        .query("SELECT SubjectID FROM dbo.Subjects WHERE SubjectID=@subjectID");
      if (!subject.recordset.length) {
        return res.status(404).json({ message: "Subject not found." });
      }

      if (classID !== null) {
        const schoolClass = await p
          .request()
          .input("classID", sql.Int, classID)
          .query("SELECT ClassID FROM dbo.Classes WHERE ClassID=@classID");
        if (!schoolClass.recordset.length) {
          return res.status(404).json({ message: "Class not found." });
        }
      }

      const existing = await p
        .request()
        .input("teacherID", sql.Int, teacherID)
        .input("subjectID", sql.Int, subjectID)
        .input("classID", sql.Int, classID)
        .query(`
          SELECT TeacherSubjectID FROM dbo.TeacherSubjects
          WHERE TeacherID=@teacherID AND SubjectID=@subjectID
            AND ((ClassID=@classID) OR (ClassID IS NULL AND @classID IS NULL));
        `);
      if (existing.recordset.length) {
        return res.json({ message: "This teaching assignment already exists." });
      }

      await p
        .request()
        .input("teacherID", sql.Int, teacherID)
        .input("subjectID", sql.Int, subjectID)
        .input("classID", sql.Int, classID)
        .query(
          "INSERT INTO dbo.TeacherSubjects(TeacherID,SubjectID,ClassID) VALUES(@teacherID,@subjectID,@classID)",
        );
      res.status(201).json({ message: "Teacher subject assignment saved." });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

async function getMessageContactableLearner(p, learnerID, teacherID) {
  const result = await p
    .request()
    .input("learnerID", sql.Int, learnerID)
    .input("teacherID", sql.Int, teacherID)
    .query(`
      SELECT learner.LearnerID, learner.FullName AS LearnerName,
        learner.ParentUserID, parent.FullName AS ParentName,
        teacher.FullName AS TeacherName
      FROM dbo.Learners AS learner
      INNER JOIN dbo.Users AS parent
        ON parent.UserID=learner.ParentUserID AND parent.Role='Parent' AND parent.Status='Active'
      INNER JOIN dbo.Users AS teacher
        ON teacher.UserID=@teacherID AND teacher.Role='Teacher' AND teacher.Status='Active'
      LEFT JOIN dbo.Classes AS schoolClass ON schoolClass.ClassID=learner.ClassID
      WHERE learner.LearnerID=@learnerID AND learner.Status='Active'
        AND learner.ClassID IS NOT NULL
        AND (
          schoolClass.ClassTeacherID=@teacherID
          OR EXISTS (
            SELECT 1 FROM dbo.TeacherSubjects AS ts
            WHERE ts.TeacherID=@teacherID
              AND (ts.ClassID=learner.ClassID OR ts.ClassID IS NULL)
          )
        );
    `);
  return result.recordset[0] || null;
}

app.get(
  "/api/messages/contacts",
  auth,
  roles("Parent", "Teacher"),
  async (req, res) => {
    try {
      const p = await db();
      if (req.user.role === "Parent") {
        const result = await p
          .request()
          .input("parentID", sql.Int, req.user.userId)
          .query(`
            SELECT DISTINCT learner.LearnerID, learner.FullName AS LearnerName,
              teacher.UserID AS TeacherID, teacher.FullName AS TeacherName,
              CASE WHEN schoolClass.ClassTeacherID=teacher.UserID
                THEN 'Class Teacher' ELSE 'Subject Teacher' END AS Assignment
            FROM dbo.Learners AS learner
            INNER JOIN dbo.Classes AS schoolClass ON schoolClass.ClassID=learner.ClassID
            INNER JOIN dbo.Users AS teacher
              ON teacher.Role='Teacher' AND teacher.Status='Active'
            WHERE learner.ParentUserID=@parentID AND learner.Status='Active'
              AND (
                schoolClass.ClassTeacherID=teacher.UserID
                OR EXISTS (
                  SELECT 1 FROM dbo.TeacherSubjects AS ts
                  WHERE ts.TeacherID=teacher.UserID
                    AND (ts.ClassID=learner.ClassID OR ts.ClassID IS NULL)
                )
              )
            ORDER BY learner.FullName, teacher.FullName;
          `);
        return res.json(result.recordset);
      }

      const result = await p
        .request()
        .input("teacherID", sql.Int, req.user.userId)
        .query(`
          SELECT learner.LearnerID, learner.FullName AS LearnerName,
            parent.UserID AS ParentID, parent.FullName AS ParentName,
            teacher.UserID AS TeacherID, latest.MessageText AS LastMessage,
            latest.SentAt AS LastMessageAt
          FROM dbo.Learners AS learner
          INNER JOIN dbo.Users AS parent ON parent.UserID=learner.ParentUserID
          INNER JOIN dbo.Users AS teacher ON teacher.UserID=@teacherID
          LEFT JOIN dbo.Classes AS schoolClass ON schoolClass.ClassID=learner.ClassID
          OUTER APPLY (
            SELECT TOP 1 message.MessageText, message.SentAt
            FROM dbo.Messages AS message
            WHERE message.LearnerID=learner.LearnerID
              AND ((message.SenderUserID=parent.UserID AND message.RecipientUserID=teacher.UserID)
                OR (message.SenderUserID=teacher.UserID AND message.RecipientUserID=parent.UserID))
            ORDER BY message.MessageID DESC
          ) AS latest
          WHERE learner.Status='Active' AND latest.SentAt IS NOT NULL
            AND EXISTS (
              SELECT 1 FROM dbo.Messages AS parentMessage
              WHERE parentMessage.LearnerID=learner.LearnerID
                AND parentMessage.SenderUserID=parent.UserID
                AND parentMessage.RecipientUserID=teacher.UserID
            )
            AND (
              schoolClass.ClassTeacherID=teacher.UserID
              OR EXISTS (
                SELECT 1 FROM dbo.TeacherSubjects AS ts
                WHERE ts.TeacherID=teacher.UserID
                  AND (ts.ClassID=learner.ClassID OR ts.ClassID IS NULL)
              )
            )
          ORDER BY latest.SentAt DESC;
        `);
      res.json(result.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/messages/:learnerID/:teacherID",
  auth,
  roles("Parent", "Teacher"),
  async (req, res) => {
    const learnerID = Number(req.params.learnerID);
    const teacherID = Number(req.params.teacherID);
    if (!Number.isInteger(learnerID) || learnerID < 1 || !Number.isInteger(teacherID) || teacherID < 1) {
      return res.status(400).json({ message: "Invalid conversation." });
    }

    try {
      const p = await db();
      const contact = await getMessageContactableLearner(p, learnerID, teacherID);
      if (!contact) {
        return res.status(404).json({ message: "Conversation not found." });
      }
      if (req.user.role === "Parent" && contact.ParentUserID !== req.user.userId) {
        return res.status(403).json({ message: "This learner is not linked to your account." });
      }
      if (req.user.role === "Teacher" && teacherID !== req.user.userId) {
        return res.status(403).json({ message: "You can only view your own conversations." });
      }
      if (req.user.role === "Teacher") {
        const parentMessage = await p
          .request()
          .input("learnerID", sql.Int, learnerID)
          .input("parentID", sql.Int, contact.ParentUserID)
          .input("teacherID", sql.Int, teacherID)
          .query(`
            SELECT TOP 1 MessageID FROM dbo.Messages
            WHERE LearnerID=@learnerID AND SenderUserID=@parentID AND RecipientUserID=@teacherID;
          `);
        if (!parentMessage.recordset.length) {
          return res.status(404).json({ message: "No parent message exists for this conversation." });
        }
      }

      const messages = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .input("parentID", sql.Int, contact.ParentUserID)
        .input("teacherID", sql.Int, teacherID)
        .input("userID", sql.Int, req.user.userId)
        .query(`
          SELECT message.MessageID, message.LearnerID, message.SenderUserID,
            message.RecipientUserID, message.MessageText, message.SentAt,
            sender.FullName AS SenderName,
            CASE WHEN message.SenderUserID=@userID THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsMine
          FROM dbo.Messages AS message
          INNER JOIN dbo.Users AS sender ON sender.UserID=message.SenderUserID
          WHERE message.LearnerID=@learnerID
            AND ((message.SenderUserID=@parentID AND message.RecipientUserID=@teacherID)
              OR (message.SenderUserID=@teacherID AND message.RecipientUserID=@parentID))
          ORDER BY message.MessageID;
        `);
      res.json(messages.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/messages",
  auth,
  roles("Parent", "Teacher"),
  async (req, res) => {
    const learnerID = Number(req.body.learnerID);
    const teacherID = Number(req.body.teacherID);
    const messageText = String(req.body.messageText || "").trim();
    if (!Number.isInteger(learnerID) || learnerID < 1 || !Number.isInteger(teacherID) || teacherID < 1) {
      return res.status(400).json({ message: "Choose a valid learner and teacher." });
    }
    if (!messageText || messageText.length > 2000) {
      return res.status(400).json({ message: "Message must contain 1 to 2000 characters." });
    }

    try {
      const p = await db();
      const contact = await getMessageContactableLearner(p, learnerID, teacherID);
      if (!contact) {
        return res.status(404).json({ message: "This teacher is not assigned to the learner." });
      }

      let recipientID;
      if (req.user.role === "Parent") {
        if (contact.ParentUserID !== req.user.userId) {
          return res.status(403).json({ message: "This learner is not linked to your account." });
        }
        recipientID = teacherID;
      } else {
        if (teacherID !== req.user.userId) {
          return res.status(403).json({ message: "You can only reply as yourself." });
        }
        const parentMessage = await p
          .request()
          .input("learnerID", sql.Int, learnerID)
          .input("parentID", sql.Int, contact.ParentUserID)
          .input("teacherID", sql.Int, teacherID)
          .query(`
            SELECT TOP 1 MessageID FROM dbo.Messages
            WHERE LearnerID=@learnerID AND SenderUserID=@parentID AND RecipientUserID=@teacherID;
          `);
        if (!parentMessage.recordset.length) {
          return res.status(403).json({ message: "Teachers can reply after a parent starts the conversation." });
        }
        recipientID = contact.ParentUserID;
      }

      const result = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .input("senderID", sql.Int, req.user.userId)
        .input("recipientID", sql.Int, recipientID)
        .input("messageText", sql.NVarChar(2000), messageText)
        .query(`
          INSERT INTO dbo.Messages(LearnerID,SenderUserID,RecipientUserID,MessageText)
          OUTPUT INSERTED.MessageID,INSERTED.LearnerID,INSERTED.SenderUserID,
            INSERTED.RecipientUserID,INSERTED.MessageText,INSERTED.SentAt
          VALUES(@learnerID,@senderID,@recipientID,@messageText);
        `);
      res.status(201).json(result.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/classes",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("teacherID", sql.Int, req.user.userId)
        .input("isTeacher", sql.Bit, req.user.role === "Teacher")
        .query(`
          SELECT c.*, u.FullName AS ClassTeacher,
            (SELECT COUNT(*) FROM dbo.Learners l WHERE l.ClassID=c.ClassID AND l.Status='Active') AS LearnerCount
          FROM dbo.Classes c
          LEFT JOIN dbo.Users u ON u.UserID=c.ClassTeacherID
          WHERE @isTeacher=0 OR c.ClassTeacherID=@teacherID OR EXISTS (
            SELECT 1 FROM dbo.TeacherSubjects ts
            WHERE ts.ClassID=c.ClassID AND ts.TeacherID=@teacherID
          )
          ORDER BY c.Grade,c.ClassName;
        `);
      res.json(r.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);
app.put(
  "/api/classes/:id/teacher",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const classID = Number(req.params.id);
    const teacherID =
      req.body.teacherID === null || req.body.teacherID === ""
        ? null
        : Number(req.body.teacherID);

    if (!Number.isInteger(classID) || classID < 1) {
      return res.status(400).json({ message: "Invalid class ID." });
    }
    if (teacherID !== null && (!Number.isInteger(teacherID) || teacherID < 1)) {
      return res.status(400).json({ message: "Invalid teacher ID." });
    }

    try {
      const p = await db();
      if (teacherID !== null) {
        const teacher = await p
          .request()
          .input("teacherID", sql.Int, teacherID)
          .query(
            "SELECT UserID FROM dbo.Users WHERE UserID=@teacherID AND Role='Teacher' AND Status='Active'",
          );
        if (!teacher.recordset.length) {
          return res.status(404).json({ message: "Active teacher not found." });
        }
      }

      const result = await p
        .request()
        .input("classID", sql.Int, classID)
        .input("teacherID", sql.Int, teacherID)
        .query(
          "UPDATE dbo.Classes SET ClassTeacherID=@teacherID WHERE ClassID=@classID",
        );
      if (!result.rowsAffected[0]) {
        return res.status(404).json({ message: "Class not found." });
      }
      res.json({ message: "Class teacher assignment saved." });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);
app.post(
  "/api/classes",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    try {
      const p = await db();
      const r = await p
        .request()
        .input("name", sql.NVarChar(100), req.body.name)
        .input("grade", sql.VarChar(20), req.body.grade)
        .input("room", sql.NVarChar(50), req.body.room || null)
        .query(
          "INSERT INTO Classes(ClassName,Grade,Room) OUTPUT INSERTED.* VALUES(@name,@grade,@room)",
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/timetable",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
    try {
      const p = await db();
      const result = await p
        .request()
        .input("userID", sql.Int, req.user.userId)
        .input("isAdmin", sql.Bit, req.user.role === "Administrator")
        .input("isTeacher", sql.Bit, req.user.role === "Teacher")
        .input("isParent", sql.Bit, req.user.role === "Parent")
        .query(`
          SELECT timetable.TimetableID, timetable.DayName,
            CONVERT(varchar(5), timetable.StartTime, 108) AS StartTime,
            timetable.Room, schoolClass.ClassID, schoolClass.ClassName,
            schoolClass.Grade, subject.SubjectID, subject.SubjectName,
            teacher.UserID AS TeacherID, teacher.FullName AS TeacherName
          FROM dbo.Timetable AS timetable
          INNER JOIN dbo.Classes AS schoolClass ON schoolClass.ClassID=timetable.ClassID
          INNER JOIN dbo.Subjects AS subject ON subject.SubjectID=timetable.SubjectID
          INNER JOIN dbo.Users AS teacher ON teacher.UserID=timetable.TeacherID
          WHERE @isAdmin=1
            OR (@isParent=1 AND EXISTS (
              SELECT 1 FROM dbo.Learners AS learner
              WHERE learner.ParentUserID=@userID AND learner.Status='Active'
                AND learner.Grade=schoolClass.Grade
            ))
            OR (@isTeacher=1 AND (
              timetable.TeacherID=@userID
              OR schoolClass.ClassTeacherID=@userID
              OR EXISTS (
                SELECT 1 FROM dbo.TeacherSubjects AS teacherSubject
                WHERE teacherSubject.TeacherID=@userID
                  AND teacherSubject.SubjectID=timetable.SubjectID
                  AND (teacherSubject.ClassID=schoolClass.ClassID OR teacherSubject.ClassID IS NULL)
              )
            ))
          ORDER BY CASE timetable.DayName
            WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
            WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6
            ELSE 7 END,
            timetable.StartTime, schoolClass.Grade, schoolClass.ClassName;
        `);
      res.json(result.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/timetable",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const classID = Number(req.body.classID);
    const subjectID = Number(req.body.subjectID);
    const teacherID = Number(req.body.teacherID);
    const dayName = String(req.body.dayName || "");
    const startTime = String(req.body.startTime || "");
    const room = String(req.body.room || "").trim();
    const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

    if (!Number.isInteger(classID) || classID < 1 || !Number.isInteger(subjectID) || subjectID < 1 || !Number.isInteger(teacherID) || teacherID < 1) {
      return res.status(400).json({ message: "Choose a valid class, subject and teacher." });
    }
    if (!validDays.includes(dayName) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) {
      return res.status(400).json({ message: "Choose a weekday and valid start time." });
    }
    if (room.length > 50) {
      return res.status(400).json({ message: "Room must be 50 characters or fewer." });
    }

    try {
      const p = await db();
      const assignment = await p
        .request()
        .input("classID", sql.Int, classID)
        .input("subjectID", sql.Int, subjectID)
        .input("teacherID", sql.Int, teacherID)
        .query(`
          SELECT schoolClass.ClassID
          FROM dbo.Classes AS schoolClass
          INNER JOIN dbo.Subjects AS subject ON subject.SubjectID=@subjectID
          INNER JOIN dbo.Users AS teacher
            ON teacher.UserID=@teacherID AND teacher.Role='Teacher' AND teacher.Status='Active'
          WHERE schoolClass.ClassID=@classID
            AND (schoolClass.ClassTeacherID=@teacherID OR EXISTS (
              SELECT 1 FROM dbo.TeacherSubjects AS teacherSubject
              WHERE teacherSubject.TeacherID=@teacherID
                AND teacherSubject.SubjectID=@subjectID
                AND (teacherSubject.ClassID=@classID OR teacherSubject.ClassID IS NULL)
            ));
        `);
      if (!assignment.recordset.length) {
        return res.status(400).json({
          message: "The teacher must be assigned to this class or subject first.",
        });
      }

      const conflict = await p
        .request()
        .input("classID", sql.Int, classID)
        .input("teacherID", sql.Int, teacherID)
        .input("dayName", sql.VarChar(20), dayName)
        .input("startTime", sql.VarChar(5), startTime)
        .query(`
          SELECT TOP 1 TimetableID FROM dbo.Timetable
          WHERE DayName=@dayName AND StartTime=CONVERT(time,@startTime)
            AND (ClassID=@classID OR TeacherID=@teacherID);
        `);
      if (conflict.recordset.length) {
        return res.status(409).json({
          message: "That class or teacher already has a lesson at this time.",
        });
      }

      const result = await p
        .request()
        .input("classID", sql.Int, classID)
        .input("subjectID", sql.Int, subjectID)
        .input("teacherID", sql.Int, teacherID)
        .input("dayName", sql.VarChar(20), dayName)
        .input("startTime", sql.VarChar(5), startTime)
        .input("room", sql.NVarChar(50), room || null)
        .query(`
          INSERT INTO dbo.Timetable(ClassID,SubjectID,TeacherID,DayName,StartTime,Room)
          OUTPUT INSERTED.TimetableID
          VALUES(@classID,@subjectID,@teacherID,@dayName,CONVERT(time,@startTime),@room);
        `);
      res.status(201).json({
        message: "Timetable entry created.",
        timetableID: result.recordset[0].TimetableID,
      });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.delete(
  "/api/timetable/:id",
  auth,
  roles("Administrator"),
  async (req, res) => {
    const timetableID = Number(req.params.id);
    if (!Number.isInteger(timetableID) || timetableID < 1) {
      return res.status(400).json({ message: "Invalid timetable entry." });
    }
    try {
      const p = await db();
      const result = await p
        .request()
        .input("timetableID", sql.Int, timetableID)
        .query("DELETE FROM dbo.Timetable WHERE TimetableID=@timetableID");
      if (!result.rowsAffected[0]) {
        return res.status(404).json({ message: "Timetable entry not found." });
      }
      res.json({ message: "Timetable entry deleted." });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/results",
  auth,
  roles("Teacher", "Administrator"),
  async (req, res) => {
    try {
      const { learnerId, subjectId, term, mark, comment } = req.body;
      const learnerID = Number(learnerId);
      const subjectID = Number(subjectId);
      const numericMark = Number(mark);
      const validTerms = ["Term 1", "Term 2", "Term 3", "Term 4"];
      if (!Number.isInteger(learnerID) || learnerID < 1 || !Number.isInteger(subjectID) || subjectID < 1) {
        return res.status(400).json({ message: "Choose a valid learner and subject." });
      }
      if (!validTerms.includes(term) || !Number.isFinite(numericMark) || numericMark < 0 || numericMark > 100) {
        return res.status(400).json({ message: "Choose a valid term and a mark from 0 to 100." });
      }

      const p = await db();
      const learner = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .query("SELECT LearnerID,ClassID FROM dbo.Learners WHERE LearnerID=@learnerID AND Status='Active'");
      if (!learner.recordset.length) {
        return res.status(404).json({ message: "Active learner not found." });
      }
      const assignedClassID = learner.recordset[0].ClassID;
      if (req.user.role === "Teacher") {
        if (!assignedClassID) {
          return res.status(400).json({ message: "Assign the learner to a class before entering results." });
        }
        const assignment = await p
          .request()
          .input("classID", sql.Int, assignedClassID)
          .input("subjectID", sql.Int, subjectID)
          .input("teacherID", sql.Int, req.user.userId)
          .query(`
            SELECT schoolClass.ClassID FROM dbo.Classes AS schoolClass
            INNER JOIN dbo.Subjects AS subject ON subject.SubjectID=@subjectID
            WHERE schoolClass.ClassID=@classID
              AND (schoolClass.ClassTeacherID=@teacherID OR EXISTS (
                SELECT 1 FROM dbo.TeacherSubjects AS teacherSubject
                WHERE teacherSubject.TeacherID=@teacherID
                  AND teacherSubject.SubjectID=@subjectID
                  AND (teacherSubject.ClassID=@classID OR teacherSubject.ClassID IS NULL)
              ));
          `);
        if (!assignment.recordset.length) {
          return res.status(403).json({ message: "You are not assigned to teach this learner and subject." });
        }
      }

      const r = await p
        .request()
        .input("learner", sql.Int, learnerID)
        .input("subject", sql.Int, subjectID)
        .input("class", sql.Int, assignedClassID)
        .input("term", sql.VarChar(20), term)
        .input("mark", sql.Decimal(5, 2), numericMark)
        .input("comment", sql.NVarChar(1000), comment || null)
        .input("by", sql.Int, req.user.userId)
        .query(
          `MERGE Results AS target USING (SELECT @learner LearnerID,@subject SubjectID,@term Term) src ON target.LearnerID=src.LearnerID AND target.SubjectID=src.SubjectID AND target.Term=src.Term WHEN MATCHED THEN UPDATE SET Mark=@mark,ClassID=@class,Comment=@comment,EnteredBy=@by WHEN NOT MATCHED THEN INSERT(LearnerID,SubjectID,ClassID,Term,Mark,Comment,EnteredBy) VALUES(@learner,@subject,@class,@term,@mark,@comment,@by) OUTPUT inserted.*;`,
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/results",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
  try {
    const p = await db();
    const q = p.request();
    let sqlText = `SELECT r.ResultID,r.LearnerID,l.FullName AS Learner,r.SubjectID,s.SubjectName AS Subject,r.Term,r.Mark,r.Comment,r.CreatedAt FROM Results r JOIN Learners l ON l.LearnerID=r.LearnerID JOIN Subjects s ON s.SubjectID=r.SubjectID`;
    if (req.user.role === "Parent") {
      sqlText += " WHERE l.ParentUserID=@parent";
      q.input("parent", sql.Int, req.user.userId);
    } else if (req.user.role === "Teacher") {
      sqlText += " WHERE r.EnteredBy=@teacher";
      q.input("teacher", sql.Int, req.user.userId);
    } else if (req.query.learnerId) {
      sqlText += " WHERE r.LearnerID=@learner";
      q.input("learner", sql.Int, Number(req.query.learnerId));
    }
    sqlText += " ORDER BY r.CreatedAt DESC";
    const r = await q.query(sqlText);
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
  },
);

app.post(
  "/api/attendance",
  auth,
  roles("Teacher", "Administrator"),
  async (req, res) => {
    try {
      const { learnerId, date, classId, subjectId, status, comment } = req.body;
      const learnerID = Number(learnerId);
      const subjectID = subjectId ? Number(subjectId) : null;
      const validStatuses = ["Present", "Absent", "Late", "Excused"];
      if (!Number.isInteger(learnerID) || learnerID < 1 || !/^\d{4}-\d{2}-\d{2}$/.test(String(date || ""))) {
        return res.status(400).json({ message: "Choose a valid learner and date." });
      }
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ message: "Choose a valid attendance status." });
      }
      if (subjectID !== null && (!Number.isInteger(subjectID) || subjectID < 1)) {
        return res.status(400).json({ message: "Choose a valid subject." });
      }

      const p = await db();
      const learner = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .query("SELECT LearnerID,ClassID FROM dbo.Learners WHERE LearnerID=@learnerID AND Status='Active'");
      if (!learner.recordset.length) {
        return res.status(404).json({ message: "Active learner not found." });
      }
      const assignedClassID = learner.recordset[0].ClassID;
      if (req.user.role === "Teacher") {
        if (!assignedClassID) {
          return res.status(400).json({ message: "Assign the learner to a class before recording attendance." });
        }
        const assignment = await p
          .request()
          .input("classID", sql.Int, assignedClassID)
          .input("subjectID", sql.Int, subjectID)
          .input("teacherID", sql.Int, req.user.userId)
          .query(`
            SELECT schoolClass.ClassID FROM dbo.Classes AS schoolClass
            WHERE schoolClass.ClassID=@classID
              AND (schoolClass.ClassTeacherID=@teacherID OR (
                @subjectID IS NOT NULL AND EXISTS (
                  SELECT 1 FROM dbo.TeacherSubjects AS teacherSubject
                  WHERE teacherSubject.TeacherID=@teacherID
                    AND teacherSubject.SubjectID=@subjectID
                    AND (teacherSubject.ClassID=@classID OR teacherSubject.ClassID IS NULL)
                )
              ));
          `);
        if (!assignment.recordset.length) {
          return res.status(403).json({ message: "You are not assigned to this learner's class or subject." });
        }
      }

      const r = await p
        .request()
        .input("learner", sql.Int, learnerID)
        .input("date", sql.Date, date)
        .input("class", sql.Int, assignedClassID || classId || null)
        .input("subject", sql.Int, subjectID)
        .input("status", sql.VarChar(20), status)
        .input("comment", sql.NVarChar(500), comment || null)
        .input("by", sql.Int, req.user.userId)
        .query(
          `INSERT INTO Attendance(LearnerID,AttendanceDate,ClassID,SubjectID,AttendanceStatus,Comment,RecordedBy) OUTPUT INSERTED.* VALUES(@learner,@date,@class,@subject,@status,@comment,@by)`,
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);
app.get(
  "/api/attendance",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
  try {
    const p = await db();
    const q = p.request();
    let s = `SELECT a.*,l.FullName AS Learner,c.ClassName,s.SubjectName AS Subject FROM Attendance a JOIN Learners l ON l.LearnerID=a.LearnerID LEFT JOIN Classes c ON c.ClassID=a.ClassID LEFT JOIN Subjects s ON s.SubjectID=a.SubjectID`;
    if (req.user.role === "Parent") {
      s += " WHERE l.ParentUserID=@parent";
      q.input("parent", sql.Int, req.user.userId);
    } else if (req.user.role === "Teacher") {
      s += " WHERE a.RecordedBy=@teacher";
      q.input("teacher", sql.Int, req.user.userId);
    } else if (req.query.learnerId) {
      s += " WHERE a.LearnerID=@learner";
      q.input("learner", sql.Int, Number(req.query.learnerId));
    }
    s += " ORDER BY a.AttendanceDate DESC";
    const r = await q.query(s);
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
  },
);

app.get(
  "/api/behaviour",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
    try {
      const p = await db();
      const query = p.request();
      let sqlText = `
        SELECT behaviour.BehaviourID,behaviour.LearnerID,learner.FullName AS Learner,
          behaviour.BehaviourDate,behaviour.Rating,behaviour.Comment,
          recorder.FullName AS RecordedBy,behaviour.CreatedAt
        FROM dbo.BehaviourRecords AS behaviour
        INNER JOIN dbo.Learners AS learner ON learner.LearnerID=behaviour.LearnerID
        INNER JOIN dbo.Users AS recorder ON recorder.UserID=behaviour.RecordedBy
      `;
      if (req.user.role === "Parent") {
        sqlText += " WHERE learner.ParentUserID=@parentID";
        query.input("parentID", sql.Int, req.user.userId);
      } else if (req.user.role === "Teacher") {
        sqlText += " WHERE behaviour.RecordedBy=@teacherID";
        query.input("teacherID", sql.Int, req.user.userId);
      }
      sqlText += " ORDER BY behaviour.BehaviourDate DESC,behaviour.BehaviourID DESC";
      const result = await query.query(sqlText);
      res.json(result.recordset);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/behaviour",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    const learnerID = Number(req.body.learnerID);
    const behaviourDate = String(req.body.behaviourDate || "");
    const rating = String(req.body.rating || "");
    const comment = String(req.body.comment || "").trim();
    const validRatings = ["Positive", "Satisfactory", "Needs Support"];
    if (!Number.isInteger(learnerID) || learnerID < 1 || !/^\d{4}-\d{2}-\d{2}$/.test(behaviourDate)) {
      return res.status(400).json({ message: "Choose a valid learner and date." });
    }
    if (!validRatings.includes(rating) || !comment || comment.length > 500) {
      return res.status(400).json({ message: "Choose a rating and enter a comment up to 500 characters." });
    }

    try {
      const p = await db();
      const learner = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .query("SELECT LearnerID,ClassID FROM dbo.Learners WHERE LearnerID=@learnerID AND Status='Active'");
      if (!learner.recordset.length) {
        return res.status(404).json({ message: "Active learner not found." });
      }
      const classID = learner.recordset[0].ClassID;
      if (req.user.role === "Teacher") {
        if (!classID) {
          return res.status(400).json({ message: "Assign the learner to a class first." });
        }
        const assignment = await p
          .request()
          .input("classID", sql.Int, classID)
          .input("teacherID", sql.Int, req.user.userId)
          .query(`
            SELECT ClassID FROM dbo.Classes
            WHERE ClassID=@classID AND (
              ClassTeacherID=@teacherID OR EXISTS (
                SELECT 1 FROM dbo.TeacherSubjects
                WHERE TeacherID=@teacherID AND (ClassID=@classID OR ClassID IS NULL)
              )
            );
          `);
        if (!assignment.recordset.length) {
          return res.status(403).json({ message: "You are not assigned to this learner's class." });
        }
      }

      const result = await p
        .request()
        .input("learnerID", sql.Int, learnerID)
        .input("recordedBy", sql.Int, req.user.userId)
        .input("behaviourDate", sql.Date, behaviourDate)
        .input("rating", sql.VarChar(30), rating)
        .input("comment", sql.NVarChar(500), comment)
        .query(`
          INSERT INTO dbo.BehaviourRecords(LearnerID,RecordedBy,BehaviourDate,Rating,Comment)
          OUTPUT INSERTED.BehaviourID,INSERTED.LearnerID,INSERTED.RecordedBy,
            INSERTED.BehaviourDate,INSERTED.Rating,INSERTED.Comment,INSERTED.CreatedAt
          VALUES(@learnerID,@recordedBy,@behaviourDate,@rating,@comment);
        `);
      res.status(201).json({ message: "Behaviour record saved.", record: result.recordset[0] });
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.get(
  "/api/announcements",
  auth,
  roles("Administrator", "Teacher", "Parent"),
  async (req, res) => {
  try {
    const p = await db();
    const audience =
      req.user.role === "Teacher"
        ? "Teachers"
        : req.user.role === "Parent"
          ? "Parents"
          : null;
    const r = await p
      .request()
      .input("audience", sql.VarChar(50), audience)
      .input("isAdmin", sql.Bit, req.user.role === "Administrator")
      .query(
        `SELECT a.*,u.FullName AS Author FROM Announcements a JOIN Users u ON u.UserID=a.PublishedBy WHERE a.Status='Published' AND (@isAdmin=1 OR a.Audience=@audience OR a.Audience='Teachers and Parents') ORDER BY a.PublishedAt DESC`,
      );
    res.json(r.recordset);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
  },
);
app.post(
  "/api/announcements",
  auth,
  roles("Administrator", "Teacher"),
  async (req, res) => {
    try {
      const title = String(req.body.title || "").trim();
      const audience = String(req.body.audience || "").trim();
      const category = String(req.body.category || "").trim();
      const message = String(req.body.message || "").trim();

      if (!title || !category || !message) {
        return res.status(400).json({
          message: "Title, category and message are required.",
        });
      }
      if (!["Teachers", "Parents", "Teachers and Parents"].includes(audience)) {
        return res.status(400).json({ message: "Invalid announcement audience." });
      }

      const p = await db();
      const r = await p
        .request()
        .input("title", sql.NVarChar(200), title)
        .input("audience", sql.VarChar(50), audience)
        .input("category", sql.VarChar(80), category)
        .input("message", sql.NVarChar(sql.MAX), message)
        .input("by", sql.Int, req.user.userId)
        .query(
          `INSERT INTO Announcements(Title,Audience,Category,Message,PublishedBy) OUTPUT INSERTED.* VALUES(@title,@audience,@category,@message,@by)`,
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }
  },
);

app.post(
  "/api/documents",
  auth,
  roles("Administrator", "Teacher"),
  upload.single("file"),
  async (req, res) => {
    try {
      if (!req.file)
        return res.status(400).json({ message: "File is required." });
      const p = await db();
      const r = await p
        .request()
        .input("title", sql.NVarChar(200), req.body.title)
        .input("audience", sql.VarChar(50), req.body.audience)
        .input("category", sql.VarChar(80), req.body.category)
        .input("file", sql.NVarChar(255), req.file.originalname)
        .input("path", sql.NVarChar(500), req.file.filename)
        .input("by", sql.Int, req.user.userId)
        .query(
          `INSERT INTO Documents(Title,Audience,Category,FileName,StoredPath,UploadedBy) OUTPUT INSERTED.* VALUES(@title,@audience,@category,@file,@path,@by)`,
        );
      res.status(201).json(r.recordset[0]);
    } catch (e) {
      res.status(500).json({ message: e.message });
    }

  },
);
app.use("/uploads", express.static(uploadDir));

async function ensureAdmin() {
  const p = await db();
  const r = await p
    .request()
    .query(`SELECT TOP 1 UserID FROM Users WHERE SystemUserID='ADM001'`);
  if (!r.recordset.length) {
    const hash = await bcrypt.hash("admin123", 12);
    await p
      .request()
      .input("sid", sql.VarChar(20), "ADM001")
      .input("name", sql.NVarChar(150), "System Administrator")
      .input("email", sql.NVarChar(255), "admin@school.local")
      .input("hash", sql.NVarChar(255), hash)
      .query(
        `INSERT INTO Users(SystemUserID,FullName,Email,PasswordHash,Role) VALUES(@sid,@name,@email,@hash,'Administrator')`,
      );
    console.log("Default administrator created: ADM001 / admin123");
  }
}

app.listen(PORT, async () => {
  try {
    await ensureAdmin();
    console.log(`High School System API running at http://localhost:${PORT}`);
  } catch (e) {
    console.error("Database startup error:", e.message);
  }
});
