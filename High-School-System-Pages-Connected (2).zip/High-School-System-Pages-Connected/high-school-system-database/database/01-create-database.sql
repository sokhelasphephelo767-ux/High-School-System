
/*
 HIGH SCHOOL SYSTEM - SQL SERVER DATABASE
 Run this script in SQL Server Management Studio (SSMS).
 It creates the database and all core tables.
*/
IF DB_ID(N'HighSchoolSystem') IS NULL
BEGIN
    CREATE DATABASE HighSchoolSystem;
END
GO

USE HighSchoolSystem;
GO

IF OBJECT_ID('dbo.Users','U') IS NULL
BEGIN
CREATE TABLE dbo.Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    SystemUserID VARCHAR(20) NOT NULL UNIQUE, -- e.g. ADM001, TCH001, PAR001
    FullName NVARCHAR(150) NOT NULL,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    Phone NVARCHAR(30) NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Administrator','Teacher','Parent','Learner')),
    Status VARCHAR(20) NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active','Inactive')),
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
END
GO

IF OBJECT_ID('dbo.AdmissionApplications','U') IS NULL
BEGIN
CREATE TABLE dbo.AdmissionApplications (
    ApplicationID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerName NVARCHAR(150) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Gender VARCHAR(20) NULL,
    Grade VARCHAR(20) NOT NULL,
    PreviousSchool NVARCHAR(200) NULL,
    ParentName NVARCHAR(150) NOT NULL,
    ClassID INT NULL,
    IDNumber NVARCHAR(50) NOT NULL,
    ParentPhone NVARCHAR(30) NOT NULL,
    ParentEmail NVARCHAR(255) NOT NULL,
    Address NVARCHAR(300) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    PostalCode NVARCHAR(20) NOT NULL,
    EmergencyName NVARCHAR(150) NOT NULL,
    EmergencyPhone NVARCHAR(30) NOT NULL,
    Relationship NVARCHAR(80) NOT NULL,
    Allergies NVARCHAR(500) NULL,
    Medical NVARCHAR(1000) NULL,
    BirthCertificateFile NVARCHAR(255) NULL,
    ResidenceFile NVARCHAR(255) NULL,
    TransferLetterFile NVARCHAR(255) NULL,
    ParentIDFile NVARCHAR(255) NULL,
    MedicalReportFile NVARCHAR(255) NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK (Status IN ('Pending','Approved','Rejected')),
    ParentUserID INT NULL,
    SubmittedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    ReviewedAt DATETIME2 NULL,
    ReviewedBy INT NULL,
    CONSTRAINT FK_Application_ParentUser FOREIGN KEY (ParentUserID) REFERENCES dbo.Users(UserID),
    CONSTRAINT FK_Application_Reviewer FOREIGN KEY (ReviewedBy) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Learners','U') IS NULL
BEGIN
CREATE TABLE dbo.Learners (
    LearnerID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NULL UNIQUE,
    ApplicationID INT NULL UNIQUE,
    FullName NVARCHAR(150) NOT NULL,
    DateOfBirth DATE NULL,
    Gender VARCHAR(20) NULL,
    Grade VARCHAR(20) NOT NULL,
    PreviousSchool NVARCHAR(200) NULL,
    ParentUserID INT NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active','Inactive')),
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Learner_User FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID),
    CONSTRAINT FK_Learner_Application FOREIGN KEY (ApplicationID) REFERENCES dbo.AdmissionApplications(ApplicationID),
    CONSTRAINT FK_Learner_Parent FOREIGN KEY (ParentUserID) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Classes','U') IS NULL
BEGIN
CREATE TABLE dbo.Classes (
    ClassID INT IDENTITY(1,1) PRIMARY KEY,
    ClassName NVARCHAR(100) NOT NULL UNIQUE,
    Grade VARCHAR(20) NOT NULL,
    Room NVARCHAR(50) NULL,
    ClassTeacherID INT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Class_Teacher FOREIGN KEY (ClassTeacherID) REFERENCES dbo.Users(UserID)
);
END
GO

IF COL_LENGTH('dbo.Learners','ClassID') IS NULL
    ALTER TABLE dbo.Learners ADD ClassID INT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Learner_Class')
    ALTER TABLE dbo.Learners
    ADD CONSTRAINT FK_Learner_Class FOREIGN KEY (ClassID) REFERENCES dbo.Classes(ClassID);
GO

IF OBJECT_ID('dbo.Subjects','U') IS NULL
BEGIN
CREATE TABLE dbo.Subjects (
    SubjectID INT IDENTITY(1,1) PRIMARY KEY,
    SubjectName NVARCHAR(100) NOT NULL,
    SubjectCode VARCHAR(20) NOT NULL UNIQUE,
    Grade VARCHAR(20) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
END
GO

IF OBJECT_ID('dbo.TeacherSubjects','U') IS NULL
BEGIN
CREATE TABLE dbo.TeacherSubjects (
    TeacherSubjectID INT IDENTITY(1,1) PRIMARY KEY,
    TeacherID INT NOT NULL,
    SubjectID INT NOT NULL,
    ClassID INT NULL,
    CONSTRAINT UQ_Teacher_Subject_Class UNIQUE (TeacherID, SubjectID, ClassID),
    CONSTRAINT FK_TS_Teacher FOREIGN KEY (TeacherID) REFERENCES dbo.Users(UserID),
    CONSTRAINT FK_TS_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
    CONSTRAINT FK_TS_Class FOREIGN KEY (ClassID) REFERENCES dbo.Classes(ClassID)
);
END
GO

IF OBJECT_ID('dbo.Messages','U') IS NULL
BEGIN
CREATE TABLE dbo.Messages (
    MessageID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    SenderUserID INT NOT NULL,
    RecipientUserID INT NOT NULL,
    MessageText NVARCHAR(2000) NOT NULL,
    SentAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Message_Learner FOREIGN KEY (LearnerID) REFERENCES dbo.Learners(LearnerID),
    CONSTRAINT FK_Message_Sender FOREIGN KEY (SenderUserID) REFERENCES dbo.Users(UserID),
    CONSTRAINT FK_Message_Recipient FOREIGN KEY (RecipientUserID) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Results','U') IS NULL
BEGIN
CREATE TABLE dbo.Results (
    ResultID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    SubjectID INT NOT NULL,
    ClassID INT NULL,
    Term VARCHAR(20) NOT NULL,
    Mark DECIMAL(5,2) NOT NULL CHECK (Mark >= 0 AND Mark <= 100),
    Comment NVARCHAR(1000) NULL,
    EnteredBy INT NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Result UNIQUE (LearnerID, SubjectID, Term),
    CONSTRAINT FK_Result_Learner FOREIGN KEY (LearnerID) REFERENCES dbo.Learners(LearnerID),
    CONSTRAINT FK_Result_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
    CONSTRAINT FK_Result_Class FOREIGN KEY (ClassID) REFERENCES dbo.Classes(ClassID),
    CONSTRAINT FK_Result_Teacher FOREIGN KEY (EnteredBy) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Attendance','U') IS NULL
BEGIN
CREATE TABLE dbo.Attendance (
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    ClassID INT NULL,
    SubjectID INT NULL,
    AttendanceStatus VARCHAR(20) NOT NULL CHECK (AttendanceStatus IN ('Present','Absent','Late','Excused')),
    Comment NVARCHAR(500) NULL,
    RecordedBy INT NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Attendance UNIQUE (LearnerID, AttendanceDate, SubjectID),
    CONSTRAINT FK_Att_Learner FOREIGN KEY (LearnerID) REFERENCES dbo.Learners(LearnerID),
    CONSTRAINT FK_Att_Class FOREIGN KEY (ClassID) REFERENCES dbo.Classes(ClassID),
    CONSTRAINT FK_Att_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
    CONSTRAINT FK_Att_User FOREIGN KEY (RecordedBy) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.BehaviourRecords','U') IS NULL
BEGIN
CREATE TABLE dbo.BehaviourRecords (
    BehaviourID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    RecordedBy INT NOT NULL,
    BehaviourDate DATE NOT NULL,
    Rating VARCHAR(30) NOT NULL CHECK (Rating IN ('Positive','Satisfactory','Needs Support')),
    Comment NVARCHAR(500) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Behaviour_Learner FOREIGN KEY (LearnerID) REFERENCES dbo.Learners(LearnerID),
    CONSTRAINT FK_Behaviour_User FOREIGN KEY (RecordedBy) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Timetable','U') IS NULL
BEGIN
CREATE TABLE dbo.Timetable (
    TimetableID INT IDENTITY(1,1) PRIMARY KEY,
    ClassID INT NOT NULL,
    SubjectID INT NOT NULL,
    TeacherID INT NOT NULL,
    DayName VARCHAR(20) NOT NULL,
    StartTime TIME NOT NULL,
    Room NVARCHAR(50) NULL,
    CONSTRAINT FK_TT_Class FOREIGN KEY (ClassID) REFERENCES dbo.Classes(ClassID),
    CONSTRAINT FK_TT_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
    CONSTRAINT FK_TT_Teacher FOREIGN KEY (TeacherID) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Announcements','U') IS NULL
BEGIN
CREATE TABLE dbo.Announcements (
    AnnouncementID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    Audience VARCHAR(50) NOT NULL,
    Category VARCHAR(80) NOT NULL,
    Message NVARCHAR(MAX) NOT NULL,
    PublishedBy INT NOT NULL,
    PublishedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    Status VARCHAR(20) NOT NULL DEFAULT 'Published',
    CONSTRAINT FK_Announcement_User FOREIGN KEY (PublishedBy) REFERENCES dbo.Users(UserID)
);
END
GO

IF OBJECT_ID('dbo.Documents','U') IS NULL
BEGIN
CREATE TABLE dbo.Documents (
    DocumentID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    Audience VARCHAR(50) NOT NULL,
    Category VARCHAR(80) NOT NULL,
    FileName NVARCHAR(255) NOT NULL,
    StoredPath NVARCHAR(500) NOT NULL,
    UploadedBy INT NOT NULL,
    UploadedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Document_User FOREIGN KEY (UploadedBy) REFERENCES dbo.Users(UserID)
);
END
GO

-- Seed subjects used by the existing pages.
IF NOT EXISTS (SELECT 1 FROM dbo.Subjects)
BEGIN
    INSERT INTO dbo.Subjects (SubjectName, SubjectCode, Grade) VALUES
    ('Mathematics','MATH','Grade 8-12'),
    ('English','ENG','Grade 8-12'),
    ('Life Sciences','LIFE','Grade 10-12'),
    ('Physical Sciences','PHY','Grade 10-12'),
    ('Geography','GEO','Grade 8-12'),
    ('History','HIST','Grade 8-12'),
    ('Accounting','ACC','Grade 10-12'),
    ('Business Studies','BUS','Grade 10-12');
END
GO

CREATE OR ALTER VIEW dbo.vw_DashboardStats AS
SELECT
    (SELECT COUNT(*) FROM dbo.Users WHERE Role <> 'Learner') AS TotalUsers,
    (SELECT COUNT(*) FROM dbo.Learners WHERE Status = 'Active') AS TotalLearners,
    (SELECT COUNT(*) FROM dbo.Users WHERE Role = 'Teacher' AND Status = 'Active') AS TotalTeachers,
    (SELECT COUNT(*) FROM dbo.AdmissionApplications WHERE Status = 'Pending') AS PendingApplications;
GO
