// ======================================================
// HIGH SCHOOL SYSTEM - MAIN JAVASCRIPT
// ======================================================
// ======================================================
// 1. API SETTINGS
// ======================================================
const API_BASE = "http://localhost:3000/api";
let activeMessageContact = null;
let timetableAdminClasses = [];
let timetableAdminTeachers = [];
let timetableAdminSubjectAssignments = [];
let reportLearners = [];
// ======================================================
// 2. GET LOGIN TOKEN
// ======================================================
function getToken() {
  return localStorage.getItem("token");
}

function normalizeRoleValue(role) {
  const value = String(role || "").trim();
  const aliases = {
    admin: "Administrator",
    administrator: "Administrator",
    teacher: "Teacher",
    parent: "Parent",
    learner: "Learner",
  };
  return aliases[value.toLowerCase()] || value;
}

function getResultArray(result, key) {
  if (Array.isArray(result)) return result;
  if (result && Array.isArray(result[key])) return result[key];
  if (result && Array.isArray(result.data)) return result.data;
  return [];
}
// ======================================================
// 3. GET LOGGED-IN USER
// ======================================================
function getLoggedInUser() {
  const user = localStorage.getItem("user");
  if (!user) {
    return null;
  }
  try {
    return JSON.parse(user);
  } catch (error) {
    console.error("Could not read logged-in user:", error);
    return null;
  }
}
// ======================================================
// 4. API FUNCTION
// ======================================================

function getToken() {
  return localStorage.getItem("token");
}

async function api(endpoint, options = {}) {
  const token = getToken();

  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };

  if (token) {
    headers.Authorization = "Bearer " + token;
  }

  const response = await fetch(API_BASE + endpoint, {
    ...options,
    headers: headers,
  });

  let data = {};

  try {
    data = await response.json();
  } catch (error) {
    // Response may not contain JSON.
  }

  if (!response.ok) {
    throw new Error(data.message || data.error || "Server request failed.");
  }

  return data;
}
async function displayApplications() {
  alert("Token: " + localStorage.getItem("token"));

  try {
    const result = await api("/applications");
    alert("Request succeeded:\n" + JSON.stringify(result));
  } catch (error) {
    alert("Request failed:\n" + error.message);
  }
}
// ======================================================
// 5. LOGIN
// ======================================================
async function doLogin(event) {
  if (event) {
    event.preventDefault();
  }

  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");

  if (!usernameInput || !passwordInput) {
    alert("Login fields could not be found.");
    return false;
  }

  const systemUserID = usernameInput.value.trim();
  const password = passwordInput.value;
  const roleInput = document.querySelector('input[name="role"]:checked');
  const role = roleInput ? roleInput.value : "";
  const normalizedRole = normalizeRoleValue(role);

  if (!systemUserID || !password || !normalizedRole) {
    alert("Please enter your User ID, password and select your role.");
    return false;
  }

  try {
    const result = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        userID: systemUserID,
        password: password,
        role: normalizedRole,
      }),
    });

    console.log("Login successful:", result);

    localStorage.setItem("token", result.token);
    localStorage.setItem("user", JSON.stringify(result.user));

    const loggedUser = result.user;
    const userRole = loggedUser.role.toLowerCase();

    if (userRole === "administrator" || userRole === "admin") {
      window.location.href = "admin-dashboard.html";
    } else if (userRole === "teacher") {
      window.location.href = "teacher-dashboard.html";
    } else if (userRole === "parent") {
      window.location.href = "parent-dashboard.html";
    } else if (userRole === "learner") {
      window.location.href = "learner.html";
    } else {
      alert("Unknown user role: " + loggedUser.role);
    }
  } catch (error) {
    console.error("Login error:", error);
    alert(error.message || "Login failed.");
  }

  return false;
}
// ======================================================
// 6. LOGOUT
// ======================================================
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}
// ======================================================
// 7. REQUIRE LOGIN
// ======================================================
function requireLogin() {
  const token = getToken();
  if (!token) {
    window.location.href = "login.html";
    return false;
  }
  return true;
}
// ======================================================
// 8. REQUIRE ROLE
// ======================================================
function requireRole(requiredRole) {
  const token = getToken();
  const user = getLoggedInUser();
  if (!token || !user) {
    window.location.href = "login.html";
    return false;
  }
  if (user.role !== requiredRole) {
    alert("You are not allowed to access this page.");
    window.location.href = "login.html";
    return false;
  }
  return true;
}
// ======================================================
// 9. SHOW MESSAGE
// ======================================================
function showMessage(elementId, message, type = "success") {
  const element = document.getElementById(elementId);
  if (!element) {
    alert(message);
    return;
  }
  element.textContent = message;
  element.className = type;
  setTimeout(function () {
    element.textContent = "";
  }, 5000);
}
// ======================================================
// 10. ADD USER
// ======================================================
async function addUser(event) {
  if (event) {
    event.preventDefault();
  }
  const fullName = document.getElementById("fullName")?.value.trim();
  const email = document.getElementById("email")?.value.trim();
  const phone = document.getElementById("phone")?.value.trim();
  const password = document.getElementById("password")?.value;
  const role = normalizeRoleValue(document.getElementById("role")?.value || "");
  if (!fullName || !email || !password || !role) {
    alert("Please complete all required fields.");
    return false;
  }
  try {
    const result = await api("/users", {
      method: "POST",
      body: JSON.stringify({
        fullName,
        email,
        phone,
        password,
        role,
      }),
    });
    alert(result.message || "User created successfully!");
    if (result.user) {
      alert(
        "User created successfully!\n\n" +
          "User ID: " +
          result.user.systemUserID,
      );
    }
    const form = document.querySelector("form");
    if (form) {
      form.reset();
    }
  } catch (error) {
    console.error("Add user error:", error);
    alert(error.message || "Unable to create user.");
  }
  return false;
}
// ======================================================
// 11. DISPLAY USERS
// ======================================================
async function displayUsers() {
  try {
    const result = await api("/users");
    const users = getResultArray(result, "users");
    const tableBody =
      document.getElementById("usersTableBody") ||
      document.getElementById("userTableBody") ||
      document.getElementById("usersTable") ||
      document.getElementById("tableBody");
    if (!tableBody) {
      console.log("Users:", users);
      return;
    }
    tableBody.innerHTML = "";
    users.forEach(function (user) {
      const row = document.createElement("tr");
      const systemID = user.SystemUserID || user.systemUserID || "";
      row.innerHTML = `
        <td>${systemID}</td>
        <td>${user.FullName || user.fullName || ""}</td>
        <td>${user.Email || user.email || ""}</td>
        <td>${user.Role || user.role || ""}</td>
        <td>${user.Status || user.status || ""}</td>
        <td>
          <button onclick="deleteUser('${systemID}')">
            Delete
          </button>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display users error:", error);
    alert(error.message || "Unable to load users.");
  }
}
// ======================================================
// 12. DELETE USER
// ======================================================
async function deleteUser(systemID) {
  if (!systemID) {
    alert("User ID is missing.");
    return;
  }
  if (!confirm("Are you sure you want to deactivate this user?")) {
    return;
  }
  try {
    const result = await api("/users/" + encodeURIComponent(systemID), {
      method: "DELETE",
    });
    alert(result.message || "User deactivated.");
    displayUsers();
    updateDashboardStats();
  } catch (error) {
    console.error("Delete user error:", error);
    alert(error.message || "Unable to delete user.");
  }
}
// ======================================================
// 13. SUBMIT PARENT APPLICATION
// ======================================================
async function submitApplication(event) {
  if (event) {
    event.preventDefault();
  }
  // ----------------------------------------------------
  // GET LEARNER INFORMATION
  // ----------------------------------------------------
  const learnerName = document.getElementById("Lname")?.value.trim();
  const dateOfBirth = document.getElementById("age")?.value;
  const grade = document.getElementById("grade")?.value;
  const previousSchool = document.getElementById("Pschool")?.value.trim();
  // ----------------------------------------------------
  // GET PARENT INFORMATION
  // ----------------------------------------------------
  const parentName = document.getElementById("Pname")?.value.trim();
  const idNumber = document.getElementById("ID_Number")?.value.trim();
  const parentPhone = document.getElementById("PhoneNumber")?.value.trim();
  const parentEmail = document.getElementById("email")?.value.trim();
  const address = document.getElementById("address")?.value.trim();
  const city = document.getElementById("city")?.value.trim();
  const postalCode = document.getElementById("code")?.value.trim();
  // ----------------------------------------------------
  // GET EMERGENCY INFORMATION
  // ----------------------------------------------------
  const emergencyName = document.getElementById("emergencyName")?.value.trim();
  const emergencyPhone = document.getElementById("pNumber")?.value.trim();
  const relationship = document.getElementById("rel")?.value.trim();
  // ----------------------------------------------------
  // GET MEDICAL INFORMATION
  // ----------------------------------------------------
  const allergies = document.getElementById("allergies")?.value.trim();
  const medical = document.getElementById("medical")?.value.trim();
  // ----------------------------------------------------
  // GET GENDER
  // ----------------------------------------------------
  const genderInput = document.querySelector('input[name="gender"]:checked');
  const gender = genderInput ? genderInput.value : "";
  // ----------------------------------------------------
  // CHECK REQUIRED FIELDS
  // ----------------------------------------------------
  const missingFields = [];
  if (!learnerName) {
    missingFields.push("Learner's Full Name");
  }
  if (!dateOfBirth) {
    missingFields.push("Date of Birth");
  }
  if (!gender) {
    missingFields.push("Gender");
  }
  if (!grade) {
    missingFields.push("Grade");
  }
  if (!parentName) {
    missingFields.push("Parent/Guardian Name");
  }
  if (!idNumber) {
    missingFields.push("ID/Passport Number");
  }
  if (!parentPhone) {
    missingFields.push("Parent Phone Number");
  }
  if (!parentEmail) {
    missingFields.push("Parent Email");
  }
  if (!address) {
    missingFields.push("Residential Address");
  }
  if (!city) {
    missingFields.push("City/Town");
  }
  if (!postalCode) {
    missingFields.push("Postal Code");
  }
  if (!emergencyName) {
    missingFields.push("Emergency Contact Name");
  }
  if (!emergencyPhone) {
    missingFields.push("Emergency Phone Number");
  }
  if (!relationship) {
    missingFields.push("Relationship to Learner");
  }
  // ----------------------------------------------------
  // SHOW MISSING FIELDS
  // ----------------------------------------------------
  if (missingFields.length > 0) {
    alert("⚠️ These fields are missing:\n\n" + missingFields.join("\n"));

    console.log("Missing fields:", missingFields);

    return false;
  }
  // ----------------------------------------------------
  // SEND APPLICATION TO SERVER
  // ----------------------------------------------------
  try {
    const result = await api("/applications", {
      method: "POST",
      body: JSON.stringify({
        learnerName: learnerName,
        dateOfBirth: dateOfBirth,
        gender: gender,
        grade: grade,
        previousSchool: previousSchool,
        parentName: parentName,
        idNumber: idNumber,
        parentPhone: parentPhone,
        parentEmail: parentEmail,
        address: address,
        city: city,
        postalCode: postalCode,
        emergencyName: emergencyName,
        emergencyPhone: emergencyPhone,
        relationship: relationship,
        allergies: allergies,
        medical: medical,
      }),
    });
    console.log("Application submitted:", result);
    alert(result.message || "Application submitted successfully!");
    // --------------------------------------------------
    // CLEAR FORM
    // --------------------------------------------------
    document.querySelectorAll("input, select").forEach(function (field) {
      if (field.type === "radio" || field.type === "checkbox") {
        field.checked = false;
      } else {
        field.value = "";
      }
    });
  } catch (error) {
    console.error("Application submission error:", error);
    alert(error.message || "Unable to submit application.");
  }
  return false;
}
// ======================================================
// 14. DISPLAY APPLICATIONS
// ======================================================
async function displayApplications() {
  const tableBody =
    document.getElementById("applicationsTableBody") ||
    document.getElementById("applicationsTable") ||
    document.getElementById("tableBody");

  if (!tableBody) {
    console.log("Applications table was not found.");
    return;
  }

  try {
    const token = localStorage.getItem("token");

    if (!token) {
      alert("You are not logged in. Please log in again.");
      window.location.href = "login.html";
      return;
    }

    const response = await fetch("http://localhost:3000/api/applications", {
      method: "GET",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
    });

    const result = await response.json();

    console.log("Applications API response:", result);

    if (!response.ok) {
      throw new Error(
        result.message || result.error || "Unable to load applications.",
      );
    }

    const applications = getResultArray(result, "applications");

    tableBody.innerHTML = "";

    if (applications.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6">
            No applications found.
          </td>
        </tr>
      `;
      return;
    }

    applications.forEach(function (application) {
      const row = document.createElement("tr");
      const applicationID =
        application.ApplicationID || application.applicationID || application.id;
      const learnerName = application.LearnerName || application.learnerName || "";
      const parentName = application.ParentName || application.parentName || "";
      const grade = application.Grade || application.grade || "";
      const status = application.Status || application.status || "";

      row.innerHTML = `
        <td>${applicationID || ""}</td>
        <td>${learnerName}</td>
        <td>${parentName}</td>
        <td>${grade}</td>
        <td>${status}</td>
        <td>
  <button
    type="button"
    onclick="viewApplication(${applicationID})"
  >
    View Details
  </button>

  ${
    status === "Pending"
      ? `
        <button
          type="button"
          onclick="approveApplication(${applicationID})"
        >
          Approve
        </button>

        <button
          type="button"
          onclick="rejectApplication(${applicationID})"
        >
          Reject
        </button>
      `
      : ""
  }
</td>
      `;

      tableBody.appendChild(row);
    });

    async function approveApplication(applicationId) {
      const confirmed = confirm(
        "Are you sure you want to approve this application?",
      );

      if (!confirmed) {
        return;
      }

      try {
        const result = await api(`/applications/${applicationId}/approve`, {
          method: "POST",
        });

        alert(result.message || "Application approved successfully.");

        await displayApplications();
      } catch (error) {
        console.error("Approve application error:", error);
        alert(error.message || "Unable to approve application.");
      }
    }

    async function viewApplication(applicationId) {
      try {
        console.log("Viewing application:", applicationId);
        const result = await api(`/applications/${applicationId}`);
        console.log("Application received:", result);
        if (!result || !result.application) {
          alert("Application details could not be found.");
          return;
        }
        // Save the application details
        localStorage.setItem(
          "selectedApplication",
          JSON.stringify(result.application),
        );
        // Open the application details PAGE
        window.location.href = "application-details.html";
      } catch (error) {
        console.error("View application error:", error);
        alert("Unable to open application details: " + error.message);
      }
    }

    async function rejectApplication(applicationId) {
      const confirmed = confirm(
        "Are you sure you want to reject this application?",
      );

      if (!confirmed) {
        return;
      }

      try {
        const result = await api(`/applications/${applicationId}/reject`, {
          method: "POST",
        });

        alert(result.message || "Application rejected successfully.");

        await displayApplications();
      } catch (error) {
        console.error("Reject application error:", error);
        alert(error.message || "Unable to reject application.");
      }
    }
  } catch (error) {
    console.error("Display applications error:", error);

    tableBody.innerHTML = `
      <tr>
        <td colspan="6">
          Error loading applications: ${error.message}
        </td>
      </tr>
    `;
  }
}

async function loadUsers() {
  const usersTable = document.getElementById("usersTable");
  const noUsers = document.getElementById("noUsers");
  if (!usersTable) {
    return;
  }
  try {
    const result = await api("/users");
    console.log("Users from database:", result);
    const users = result.users || [];
    usersTable.innerHTML = "";
    if (users.length === 0) {
      noUsers.textContent = "No users found.";
      return;
    }
    noUsers.textContent = "";
    users.forEach(function (user) {
      const row = document.createElement("tr");
      row.innerHTML = `
  <td>${user.FullName || ""}</td>
  <td>${user.Email || ""}</td>
  <td>${user.Phone || "Not provided"}</td>
  <td>${user.Role || ""}</td>
  <td>${user.SystemUserID || ""}</td>
  <td>${user.Status || "Unknown"}</td>
  <td>
    <button
      type="button"
      onclick="deactivateUser(${user.UserID})"
      ${user.Status === "Inactive" ? "disabled" : ""}
    >
      ${user.Status === "Inactive" ? "Inactive" : "Deactivate"}
    </button>
  </td>
`;
      usersTable.appendChild(row);
    });
  } catch (error) {
    console.error("Load users error:", error);
    usersTable.innerHTML = `
      <tr>
        <td colspan="6">
          Unable to load users: ${error.message}
        </td>
      </tr>
    `;
  }
}

async function deactivateUser(userID) {
  const confirmed = confirm("Are you sure you want to deactivate this user?");

  if (!confirmed) {
    return;
  }

  try {
    const systemID =
      document.getElementById("userSystemID")?.value ||
      userID;
    const result = await api(`/users/${encodeURIComponent(systemID)}`, {
      method: "DELETE",
    });

    alert(result.message);

    // Reload the users table
    loadUsers();
  } catch (error) {
    console.error("Deactivate user error:", error);

    alert("Unable to deactivate user: " + error.message);
  }
}

// ======================================================
// 15. VIEW APPLICATION
// ======================================================
async function viewApplication(id) {
  try {
    const application = await api("/applications/" + id);
    console.log("Application details:", application);
    let message = "";
    message += "Learner: " + (application.LearnerName || "") + "\n";
    message += "Date of Birth: " + (application.DateOfBirth || "") + "\n";
    message += "Gender: " + (application.Gender || "") + "\n";
    message += "Grade: " + (application.Grade || "") + "\n";
    message += "Parent: " + (application.ParentName || "") + "\n";
    message += "Parent Phone: " + (application.ParentPhone || "") + "\n";
    message += "Parent Email: " + (application.ParentEmail || "") + "\n";
    message += "Status: " + (application.Status || "");
    alert(message);
  } catch (error) {
    console.error("View application error:", error);
    alert(error.message || "Unable to load application.");
  }
}
// ======================================================
// 16. APPROVE APPLICATION
// ======================================================
async function approveApplication(applicationId) {
  const confirmed = confirm(
    "Are you sure you want to approve this application?",
  );

  if (!confirmed) {
    return;
  }

  try {
    const result = await api(`/applications/${applicationId}/approve`, {
      method: "POST",
    });

    alert(result.message || "Application approved successfully.");

    await displayApplications();
  } catch (error) {
    console.error("Approve application error:", error);
    alert(error.message || "Unable to approve application.");
  }
}
// ======================================================
// 17. REJECT APPLICATION
// ======================================================
async function rejectApplication(applicationId) {
  const confirmed = confirm(
    "Are you sure you want to reject this application?",
  );

  if (!confirmed) {
    return;
  }

  try {
    const result = await api(`/applications/${applicationId}/reject`, {
      method: "POST",
    });

    alert(result.message || "Application rejected successfully.");

    await displayApplications();
  } catch (error) {
    console.error("Reject application error:", error);
    alert(error.message || "Unable to reject application.");
  }
}

// ======================================================
// VIEW LEARNER DETAILS
// ======================================================

async function viewLearner(learnerID) {
  try {
    const result = await api(`/learners/${learnerID}`);

    const learner = result.learner;

    if (!learner) {
      alert("Learner details could not be found.");
      return;
    }

    const details = document.getElementById("learnerDetails");
    const modal = document.getElementById("learnerModal");

    if (!details || !modal) {
      return;
    }

    details.innerHTML = `
      <p><strong>Learner Name:</strong> ${learner.FullName || ""}</p>
      <p><strong>System User ID:</strong> ${learner.SystemUserID || ""}</p>
      <p><strong>Date of Birth:</strong> ${learner.DateOfBirth || ""}</p>
      <p><strong>Gender:</strong> ${learner.Gender || ""}</p>
      <p><strong>Grade:</strong> ${learner.Grade || ""}</p>
      <p><strong>Parent / Guardian:</strong> ${learner.ParentName || "Not provided"}</p>
      <p><strong>Phone:</strong> ${learner.Phone || "Not provided"}</p>
      <p><strong>Class:</strong> ${learner.ClassName || "Not assigned"}</p>
      <p><strong>Status:</strong> ${learner.Status || ""}</p>
    `;

    modal.style.display = "flex";
  } catch (error) {
    console.error("View learner error:", error);

    alert("Unable to load learner details: " + error.message);
  }
}

// ======================================================
// CLOSE LEARNER DETAILS
// ======================================================

function closeLearnerDetails() {
  const modal = document.getElementById("learnerModal");

  if (modal) {
    modal.style.display = "none";
  }
}
// ======================================================
// DISPLAY LEARNERS
// ======================================================
async function displayLearners() {
  const tableBody = document.getElementById("learnersTableBody");
  const noLearners = document.getElementById("noLearners");
  const learnerCount = document.getElementById("learnerCount");

  if (!tableBody) return;

  try {
    // Load learners and available classes from the database
    const [learnerResult, classResult] = await Promise.all([
      api("/learners"),
      api("/classes"),
    ]);

    const learners = getResultArray(learnerResult, "learners");
    const classes = getResultArray(classResult, "classes");

    tableBody.innerHTML = "";

    if (learnerCount) {
      learnerCount.textContent = learners.length;
    }

    if (learners.length === 0) {
      if (noLearners) {
        noLearners.textContent = "No accepted learners found.";
      }
      return;
    }

    if (noLearners) {
      noLearners.textContent = "";
    }

    learners.forEach(function (learner, index) {
      const row = document.createElement("tr");

      // Build the class dropdown options
      let classOptions = `<option value="">Choose class</option>`;

      const learnerGrade = String(learner.Grade || "").trim().toLowerCase();
      classes
        .filter(function (schoolClass) {
          return (
            String(schoolClass.Grade || "").trim().toLowerCase() ===
            learnerGrade
          );
        })
        .forEach(function (schoolClass) {
        const selected =
          String(schoolClass.ClassID) === String(learner.ClassID)
            ? "selected"
            : "";

        classOptions += `
          <option value="${schoolClass.ClassID}" ${selected}>
            ${schoolClass.ClassName}
          </option>
        `;
      });

      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${learner.FullName || "Not provided"}</td>
        <td>${learner.Grade || "Not provided"}</td>
        <td>${learner.ParentName || learner.UserFullName || "Not provided"}</td>
        <td>${learner.ParentPhone || "Not provided"}</td>

        <td>
          <select id="classSelect_${learner.LearnerID}">
            ${classOptions}
          </select>
          <button
            type="button"
            onclick="assignLearnerToClass(${learner.LearnerID})"
          >
            Assign
          </button>
        </td>

        <td>${learner.Status || "Unknown"}</td>

        <td>
          <button
            type="button"
            onclick="viewLearner(${learner.LearnerID})"
          >
            View Details
          </button>
        </td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display learners error:", error);

    tableBody.innerHTML = `
      <tr>
        <td colspan="8">
          Unable to load learners: ${error.message}
        </td>
      </tr>
    `;

    if (learnerCount) {
      learnerCount.textContent = "0";
    }
  }
}

// Save the selected class for a learner
async function assignLearnerToClass(learnerID) {
  const classSelect = document.getElementById(`classSelect_${learnerID}`);

  if (!classSelect) {
    alert("The class selector was not found.");
    return;
  }

  const classID = classSelect.value;

  if (!classID) {
    alert("Please choose a class first.");
    return;
  }

  try {
    await api(`/learners/${learnerID}/class`, {
      method: "PUT",
      body: JSON.stringify({
        classID: Number(classID),
      }),
    });

    alert("Learner class assigned successfully!");
    await displayLearners();
  } catch (error) {
    console.error("Assign class error:", error);
    alert(`Unable to assign class: ${error.message}`);
  }
}

// ======================================================
// DISPLAY TEACHERS
// ======================================================

async function displayTeachers() {
  const tableBody =
    document.getElementById("teachersTableBody") ||
    document.getElementById("tableBody");
  const noTeachers = document.getElementById("noTeachers");
  const teacherCount = document.getElementById("teacherCount");

  if (!tableBody) {
    return;
  }

  try {
    const result = await api("/teachers");

    console.log("Teachers from database:", result);

    const teachers = getResultArray(result, "teachers");

    tableBody.innerHTML = "";

    // Update teacher count
    if (teacherCount) {
      teacherCount.textContent = teachers.length;
    }

    // No teachers
    if (teachers.length === 0) {
      if (noTeachers) {
        noTeachers.textContent = "No teachers found.";
      }
      return;
    }

    if (noTeachers) {
      noTeachers.textContent = "";
    }

    // Display teachers
    teachers.forEach(function (teacher, index) {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${index + 1}</td>

        <td>${teacher.FullName || "Not provided"}</td>

        <td>${teacher.Email || "Not provided"}</td>

        <td>${teacher.Phone || "Not provided"}</td>

        <td>${teacher.SystemUserID || "Not provided"}</td>

        <td>${teacher.Status || "Unknown"}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display teachers error:", error);

    tableBody.innerHTML = `
      <tr>
        <td colspan="6">
          Unable to load teachers: ${error.message}
        </td>
      </tr>
    `;

    if (teacherCount) {
      teacherCount.textContent = "0";
    }
  }
}

// ======================================================
// DISPLAY PARENTS
// ======================================================

async function displayParents() {
  const tableBody =
    document.getElementById("parentsTableBody") ||
    document.getElementById("tableBody");
  const noParents = document.getElementById("noParents");
  const parentCount = document.getElementById("parentCount");

  if (!tableBody) {
    return;
  }

  try {
    const result = await api("/parents");

    console.log("Parents from database:", result);

    const parents = getResultArray(result, "parents");

    tableBody.innerHTML = "";

    // Update parent count
    if (parentCount) {
      parentCount.textContent = parents.length;
    }

    // No parents
    if (parents.length === 0) {
      if (noParents) {
        noParents.textContent = "No parents found.";
      }
      return;
    }

    if (noParents) {
      noParents.textContent = "";
    }

    // Display parents
    parents.forEach(function (parent, index) {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${parent.FullName || "Not provided"}</td>
        <td>${parent.Email || "Not provided"}</td>
        <td>${parent.Phone || "Not provided"}</td>
        <td>${parent.SystemUserID || "Not provided"}</td>
        <td>${parent.Status || "Unknown"}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display parents error:", error);

    tableBody.innerHTML = `
      <tr>
        <td colspan="6">
          Unable to load parents: ${error.message}
        </td>
      </tr>
    `;

    if (parentCount) {
      parentCount.textContent = "0";
    }
  }
}
// ======================================================
// 20. DISPLAY SUBJECTS
// ======================================================
async function displaySubjects() {
  const tableBody = document.getElementById("teacherSubjectAssignmentsTableBody");
  const teacherSelect = document.getElementById("assignmentTeacherID");
  const subjectSelect = document.getElementById("assignmentSubjectID");
  const classSelect = document.getElementById("assignmentClassID");

  if (!tableBody) return;

  try {
    const [subjectResult, teacherResult, classResult, assignmentResult] =
      await Promise.all([
        api("/subjects"),
        api("/teachers"),
        api("/classes"),
        api("/teacher-subjects"),
      ]);
    const subjects = getResultArray(subjectResult, "subjects");
    const teachers = getResultArray(teacherResult, "teachers").filter(
      (teacher) => teacher.Status === "Active",
    );
    const classes = getResultArray(classResult, "classes");
    const assignments = getResultArray(assignmentResult, "assignments");

    const populate = function (select, placeholder, items, getValue, getLabel) {
      if (!select) return;
      select.replaceChildren(new Option(placeholder, ""));
      items.forEach(function (item) {
        select.add(new Option(getLabel(item), getValue(item)));
      });
    };

    populate(
      teacherSelect,
      "Select teacher",
      teachers,
      (teacher) => teacher.UserID,
      (teacher) => `${teacher.FullName} (${teacher.SystemUserID})`,
    );
    populate(
      subjectSelect,
      "Select subject",
      subjects,
      (subject) => subject.SubjectID,
      (subject) => `${subject.SubjectName} (${subject.SubjectCode})`,
    );
    populate(
      classSelect,
      "All classes",
      classes,
      (schoolClass) => schoolClass.ClassID,
      (schoolClass) => `${schoolClass.ClassName} - ${schoolClass.Grade}`,
    );

    tableBody.replaceChildren();
    if (!assignments.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 4;
      cell.textContent = "No teacher subject assignments yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    assignments.forEach(function (assignment) {
      const row = document.createElement("tr");
      [
        assignment.TeacherName,
        assignment.SubjectName,
        assignment.SubjectCode,
        assignment.ClassName || "All classes",
      ].forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value || "";
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display subjects error:", error);
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.textContent = `Unable to load teacher assignments: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

async function assignTeacherSubject(event) {
  if (event) event.preventDefault();

  const teacherID = document.getElementById("assignmentTeacherID")?.value;
  const subjectID = document.getElementById("assignmentSubjectID")?.value;
  const classID = document.getElementById("assignmentClassID")?.value;

  if (!teacherID || !subjectID) {
    showMessage(
      "teacherAssignmentMessage",
      "Choose both a teacher and a subject.",
      "error",
    );
    return false;
  }

  try {
    const result = await api("/teacher-subjects", {
      method: "POST",
      body: JSON.stringify({
        teacherID: Number(teacherID),
        subjectID: Number(subjectID),
        classID: classID ? Number(classID) : null,
      }),
    });
    showMessage(
      "teacherAssignmentMessage",
      result.message || "Teacher assignment saved.",
      "success",
    );
    await displaySubjects();
  } catch (error) {
    showMessage(
      "teacherAssignmentMessage",
      error.message || "Unable to save teacher assignment.",
      "error",
    );
  }

  return false;
}

async function displayTeacherClasses() {
  const tableBody = document.getElementById("teacherClassesTableBody");
  if (!tableBody) return;

  try {
    const result = await api("/classes");
    const classes = getResultArray(result, "classes");
    tableBody.replaceChildren();

    if (!classes.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 5;
      cell.textContent = "No classes yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    classes.forEach(function (schoolClass) {
      const row = document.createElement("tr");
      [
        schoolClass.ClassName,
        schoolClass.Grade,
        schoolClass.Room || "Not assigned",
        schoolClass.ClassTeacher || "Subject teacher",
        schoolClass.LearnerCount ?? 0,
      ].forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display teacher classes error:", error);
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.textContent = `Unable to load assigned classes: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

async function displayTeacherSubjects() {
  const tableBody = document.getElementById("teacherSubjectsTableBody");
  if (!tableBody) return;

  try {
    const result = await api("/teacher-subjects");
    const assignments = getResultArray(result, "assignments");
    tableBody.replaceChildren();

    if (!assignments.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 3;
      cell.textContent = "No subjects have been assigned to you yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    assignments.forEach(function (assignment) {
      const row = document.createElement("tr");
      [
        assignment.SubjectName,
        assignment.SubjectCode,
        assignment.ClassName || "All classes",
      ].forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value || "";
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display teacher subjects error:", error);
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 3;
    cell.textContent = `Unable to load assigned subjects: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

async function loadMessageContacts() {
  const parentContactList = document.getElementById("parentMessageContacts");
  const teacherContactList = document.getElementById("teacherMessageContacts");
  const contactList = parentContactList || teacherContactList;
  if (!contactList) return;

  const isParent = Boolean(parentContactList);
  try {
    const result = await api("/messages/contacts");
    const contacts = getResultArray(result, "contacts");
    contactList.replaceChildren();

    if (!contacts.length) {
      const emptyState = document.createElement("p");
      emptyState.className = "message-empty-state";
      emptyState.textContent = isParent
        ? "No teachers are assigned to your children yet."
        : "No parent messages yet.";
      contactList.appendChild(emptyState);
      activeMessageContact = null;
      return;
    }

    let firstContact = null;
    let selectedContactFound = false;
    contacts.forEach(function (contact) {
      const normalizedContact = {
        learnerID: Number(contact.LearnerID),
        teacherID: Number(contact.TeacherID),
        learnerName: contact.LearnerName || "Learner",
        teacherName: contact.TeacherName || "Teacher",
        parentID: Number(contact.ParentID || 0),
        parentName: contact.ParentName || "Parent",
      };
      if (!firstContact) firstContact = normalizedContact;

      const button = document.createElement("button");
      button.type = "button";
      button.className = "message-contact";
      button.textContent = isParent
        ? `${normalizedContact.teacherName} · ${normalizedContact.learnerName}`
        : `${normalizedContact.parentName} · ${normalizedContact.learnerName}`;
      button.addEventListener("click", function () {
        openMessageConversation(normalizedContact);
      });
      contactList.appendChild(button);

      if (
        activeMessageContact &&
        normalizedContact.learnerID === activeMessageContact.learnerID &&
        normalizedContact.teacherID === activeMessageContact.teacherID
      ) {
        activeMessageContact = normalizedContact;
        button.classList.add("active");
        selectedContactFound = true;
      }
    });

    if (!activeMessageContact || !selectedContactFound) {
      await openMessageConversation(firstContact);
    }
  } catch (error) {
    console.error("Load message contacts error:", error);
    contactList.replaceChildren();
    const errorMessage = document.createElement("p");
    errorMessage.className = "message-empty-state";
    errorMessage.textContent = `Unable to load contacts: ${error.message}`;
    contactList.appendChild(errorMessage);
  }
}

async function openMessageConversation(contact) {
  activeMessageContact = contact;
  const header = document.getElementById("messageConversationTitle");
  const learnerLabel = document.getElementById("messageLearnerLabel");
  const messagesList = document.getElementById("chatMessages");
  const messageInput = document.getElementById("messageInput");
  const sendButton = document.getElementById("sendMessageButton");
  const isParent = Boolean(document.getElementById("parentMessageContacts"));

  if (header) {
    header.textContent = isParent
      ? contact.teacherName
      : contact.parentName;
  }
  if (learnerLabel) {
    learnerLabel.textContent = `Regarding ${contact.learnerName}`;
  }
  if (messageInput) messageInput.disabled = false;
  if (sendButton) sendButton.disabled = false;

  document.querySelectorAll(".message-contact").forEach(function (button) {
    button.classList.toggle(
      "active",
      button.textContent ===
        (isParent
          ? `${contact.teacherName} · ${contact.learnerName}`
          : `${contact.parentName} · ${contact.learnerName}`),
    );
  });

  if (!messagesList) return;
  messagesList.replaceChildren();
  try {
    const result = await api(
      `/messages/${contact.learnerID}/${contact.teacherID}`,
    );
    const messages = getResultArray(result, "messages");
    if (!messages.length) {
      const emptyState = document.createElement("p");
      emptyState.className = "message-empty-state";
      emptyState.textContent = "No messages yet. Start the conversation.";
      messagesList.appendChild(emptyState);
      return;
    }

    messages.forEach(function (message) {
      const bubble = document.createElement("article");
      bubble.className = message.IsMine ? "message-bubble message-mine" : "message-bubble";
      const sender = document.createElement("strong");
      sender.textContent = message.SenderName || "Message";
      const body = document.createElement("p");
      body.textContent = message.MessageText || "";
      const sentAt = document.createElement("time");
      sentAt.dateTime = message.SentAt || "";
      sentAt.textContent = message.SentAt
        ? new Date(message.SentAt).toLocaleString()
        : "";
      bubble.append(sender, body, sentAt);
      messagesList.appendChild(bubble);
    });
    messagesList.scrollTop = messagesList.scrollHeight;
  } catch (error) {
    console.error("Load message conversation error:", error);
    const errorMessage = document.createElement("p");
    errorMessage.className = "message-empty-state";
    errorMessage.textContent = `Unable to load messages: ${error.message}`;
    messagesList.appendChild(errorMessage);
  }
}

async function sendSchoolMessage(event) {
  if (event) event.preventDefault();
  const messageInput = document.getElementById("messageInput");
  const messageText = messageInput?.value.trim();
  if (!activeMessageContact || !messageText) return false;

  try {
    await api("/messages", {
      method: "POST",
      body: JSON.stringify({
        learnerID: activeMessageContact.learnerID,
        teacherID: activeMessageContact.teacherID,
        messageText,
      }),
    });
    messageInput.value = "";
    showMessage("messageStatus", "Message sent.", "success");
    await openMessageConversation(activeMessageContact);
    await loadMessageContacts();
  } catch (error) {
    showMessage(
      "messageStatus",
      error.message || "Unable to send message.",
      "error",
    );
  }
  return false;
}

// ======================================================
// DISPLAY CLASSES
// ======================================================

// ======================================================
// DISPLAY CLASSES AND ASSIGN CLASS TEACHERS
// ======================================================

async function displayClasses() {
  const tableBody =
    document.getElementById("classesTableBody") ||
    document.getElementById("tableBody");
  const classCount = document.getElementById("classCount");

  if (!tableBody) return;

  tableBody.innerHTML = `
    <tr>
      <td colspan="7">Loading classes...</td>
    </tr>
  `;

  try {
    const [classResult, teacherResult] = await Promise.all([
      api("/classes"),
      api("/teachers"),
    ]);

    const classes = getResultArray(classResult, "classes");
    const teachers = getResultArray(teacherResult, "teachers");

    tableBody.innerHTML = "";

    if (classCount) {
      classCount.textContent = classes.length;
    }

    if (classes.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="7">No classes found.</td>
        </tr>
      `;
      return;
    }

    classes.forEach(function (schoolClass, index) {
      const row = document.createElement("tr");

      const teacherOptions = [
        `<option value="">Not assigned</option>`,
        ...teachers.filter((teacher) => teacher.Status === "Active").map(function (teacher) {
          const selected =
            Number(teacher.UserID) === Number(schoolClass.ClassTeacherID)
              ? "selected"
              : "";

          return `
            <option value="${teacher.UserID}" ${selected}>
              ${teacher.FullName}
            </option>
          `;
        }),
      ].join("");

      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${schoolClass.ClassName || "—"}</td>
        <td>${schoolClass.Grade || "—"}</td>
        <td>${schoolClass.Room || "Not assigned"}</td>
        <td>
          <select id="teacher-for-class-${schoolClass.ClassID}">
            ${teacherOptions}
          </select>
          <button
            type="button"
            onclick="assignClassTeacher(${schoolClass.ClassID})"
          >
            Save
          </button>
        </td>
        <td>${schoolClass.ClassID}</td>
        <td>${schoolClass.LearnerCount ?? 0}</td>
      `;

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display classes error:", error);

    tableBody.innerHTML = `
      <tr>
        <td colspan="7">
          Unable to load classes: ${error.message}
        </td>
      </tr>
    `;

    if (classCount) {
      classCount.textContent = "0";
    }
  }
}

// ======================================================
// SAVE CLASS TEACHER ASSIGNMENT
// ======================================================

async function assignClassTeacher(classID) {
  const teacherSelect = document.getElementById(`teacher-for-class-${classID}`);

  if (!teacherSelect) {
    alert("The teacher selector was not found.");
    return;
  }

  const teacherID = teacherSelect.value;

  try {
    const result = await api(`/classes/${classID}/teacher`, {
      method: "PUT",
      body: JSON.stringify({
        teacherID: teacherID === "" ? null : Number(teacherID),
      }),
    });

    alert(result.message || "Class teacher assignment saved.");
    await displayClasses();
  } catch (error) {
    console.error("Assign class teacher error:", error);
    alert("Unable to save class teacher: " + error.message);
  }
}

// ======================================================
// 22. DISPLAY RESULTS
// ======================================================
async function displayResults() {
  const tableBody =
    document.getElementById("resultsTableBody") ||
    document.getElementById("tableBody");
  if (!tableBody) return;

  try {
    const result = await api("/results");
    const results = getResultArray(result, "results");
    tableBody.replaceChildren();
    if (!results.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 6;
      cell.textContent = "No results have been entered yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    results.forEach(function (resultItem) {
      const row = document.createElement("tr");
      [
        resultItem.Learner,
        resultItem.Subject,
        resultItem.Term,
        `${resultItem.Mark}%`,
        resultItem.Comment || "—",
        resultItem.CreatedAt
          ? new Date(resultItem.CreatedAt).toLocaleDateString()
          : "—",
      ].forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value || "—";
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display results error:", error);
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 6;
    cell.textContent = `Unable to load results: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

async function initializeLearnerReportBuilder() {
  const learnerSelect = document.getElementById("reportLearnerID");
  if (!learnerSelect) return;

  try {
    const result = await api("/learners");
    reportLearners = getResultArray(result, "learners");
    learnerSelect.replaceChildren(new Option("Select learner", ""));
    reportLearners.forEach(function (learner) {
      learnerSelect.add(
        new Option(`${learner.FullName} (${learner.Grade})`, learner.LearnerID),
      );
    });
    if (!reportLearners.length) {
      showMessage("reportMessage", "No active learners found.", "error");
    }
  } catch (error) {
    showMessage(
      "reportMessage",
      `Unable to load learners: ${error.message}`,
      "error",
    );
  }
}

async function generateLearnerReport(event) {
  if (event) event.preventDefault();
  const learnerID = Number(document.getElementById("reportLearnerID")?.value);
  const term = document.getElementById("reportTerm")?.value || "";
  const learner = reportLearners.find(
    (item) => Number(item.LearnerID) === learnerID,
  );
  if (!learner) {
    showMessage("reportMessage", "Select a learner first.", "error");
    return false;
  }

  try {
    const result = await api("/results");
    const results = getResultArray(result, "results").filter(
      (item) =>
        Number(item.LearnerID) === learnerID && (!term || item.Term === term),
    );
    const reportOutput = document.getElementById("reportOutput");
    const tableBody = document.getElementById("learnerReportTableBody");
    const marks = results.map((item) => Number(item.Mark)).filter(Number.isFinite);
    const average = marks.length
      ? `${(marks.reduce((sum, mark) => sum + mark, 0) / marks.length).toFixed(1)}%`
      : "No marks yet";

    document.getElementById("reportTitle").textContent =
      `${learner.FullName} - Results Report`;
    document.getElementById("reportGrade").textContent = learner.Grade || "—";
    document.getElementById("reportClass").textContent = learner.ClassName || "Not assigned";
    document.getElementById("reportSelectedTerm").textContent = term || "All terms";
    document.getElementById("reportAverage").textContent = average;
    tableBody.replaceChildren();

    if (!results.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 5;
      cell.textContent = "No teacher-entered results found for this selection.";
      row.appendChild(cell);
      tableBody.appendChild(row);
    } else {
      results.forEach(function (item) {
        const row = document.createElement("tr");
        [
          item.Subject,
          item.Term,
          `${item.Mark}%`,
          item.Comment || "—",
          item.CreatedAt ? new Date(item.CreatedAt).toLocaleDateString() : "—",
        ].forEach(function (value) {
          const cell = document.createElement("td");
          cell.textContent = value || "—";
          row.appendChild(cell);
        });
        tableBody.appendChild(row);
      });
    }

    reportOutput.hidden = false;
    showMessage(
      "reportMessage",
      results.length ? "Report generated from saved teacher results." : "Report generated with no results for this selection.",
      "success",
    );
  } catch (error) {
    showMessage(
      "reportMessage",
      error.message || "Unable to generate learner report.",
      "error",
    );
  }
  return false;
}

async function loadParentResults() {
  const tableBody = document.getElementById("parentResultsTableBody");
  if (!tableBody) return;

  try {
    const result = await api("/results");
    const results = getResultArray(result, "results");
    tableBody.replaceChildren();
    const marks = results.map((item) => Number(item.Mark)).filter(Number.isFinite);
    const average = marks.length
      ? Math.round(marks.reduce((sum, mark) => sum + mark, 0) / marks.length)
      : 0;
    const averageElement = document.getElementById("averageMark");
    if (averageElement) averageElement.textContent = `${average}%`;

    if (!results.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 6;
      cell.textContent = "No results are available yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    results.forEach(function (resultItem) {
      const row = document.createElement("tr");
      [
        resultItem.Learner,
        resultItem.Subject,
        resultItem.Term,
        `${resultItem.Mark}%`,
        resultItem.Comment || "—",
        resultItem.CreatedAt
          ? new Date(resultItem.CreatedAt).toLocaleDateString()
          : "—",
      ].forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value || "—";
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 6;
    cell.textContent = `Unable to load results: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

function renderParentDashboardTable(tableBody, rows, valueLists, emptyMessage) {
  if (!tableBody) return;
  tableBody.replaceChildren();
  if (!rows.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = valueLists.length;
    cell.textContent = emptyMessage;
    row.appendChild(cell);
    tableBody.appendChild(row);
    return;
  }

  rows.forEach(function (record) {
    const row = document.createElement("tr");
    valueLists.forEach(function (getValue) {
      const cell = document.createElement("td");
      const value = getValue(record);
      cell.textContent = value == null || value === "" ? "—" : value;
      row.appendChild(cell);
    });
    tableBody.appendChild(row);
  });
}

async function loadParentDashboard() {
  const currentUser = getLoggedInUser();
  const parentName = currentUser?.fullName || "Parent";
  ["parentNameDisplay", "welcomeName"].forEach(function (id) {
    const element = document.getElementById(id);
    if (element) element.textContent = parentName;
  });

  try {
    const [learnerResult, resultResult, attendanceResult, behaviourResult] =
      await Promise.all([
        api("/learners"),
        api("/results"),
        api("/attendance"),
        api("/behaviour"),
      ]);
    const learners = getResultArray(learnerResult, "learners");
    const results = getResultArray(resultResult, "results");
    const attendance = getResultArray(attendanceResult, "attendance");
    const behaviour = getResultArray(behaviourResult, "behaviour");

    const setText = function (id, value) {
      const element = document.getElementById(id);
      if (element) element.textContent = value;
    };
    setText(
      "learnerNameDisplay",
      learners.length ? learners.map((learner) => learner.FullName).join(", ") : "No learner linked",
    );
    setText(
      "gradeDisplay",
      learners.length ? learners.map((learner) => learner.Grade).join(", ") : "—",
    );
    setText(
      "classDisplay",
      learners.length
        ? learners.map((learner) => learner.ClassName || "Not assigned").join(", ")
        : "—",
    );

    const marks = results.map((result) => Number(result.Mark)).filter(Number.isFinite);
    const average = marks.length
      ? Math.round(marks.reduce((sum, mark) => sum + mark, 0) / marks.length)
      : null;
    setText("dashboardResultSummary", average === null ? "No results yet" : `${average}% average · ${marks.length} results`);

    const presentCount = attendance.filter((record) => record.AttendanceStatus === "Present").length;
    const attendanceSummary = attendance.length
      ? `${presentCount}/${attendance.length} present`
      : "No attendance yet";
    setText("dashboardAttendanceSummary", attendanceSummary);
    setText(
      "dashboardBehaviourSummary",
      behaviour.length ? behaviour[0].Rating : "No behaviour notes yet",
    );

    const parentResultsTable = document.getElementById("dashboardResultsTable");
    renderParentDashboardTable(
      parentResultsTable,
      results.slice(0, 5),
      [
        (item) => item.Learner,
        (item) => item.Subject,
        (item) => item.Term,
        (item) => `${item.Mark}%`,
        (item) => item.Comment,
      ],
      "No results have been recorded yet.",
    );
    renderParentDashboardTable(
      document.getElementById("dashboardAttendanceTable"),
      attendance.slice(0, 5),
      [
        (item) => item.Learner,
        (item) => new Date(item.AttendanceDate).toLocaleDateString(),
        (item) => item.Subject || "Class attendance",
        (item) => item.AttendanceStatus,
        (item) => item.Comment,
      ],
      "No attendance has been recorded yet.",
    );
    renderParentDashboardTable(
      document.getElementById("dashboardBehaviourTable"),
      behaviour.slice(0, 5),
      [
        (item) => item.Learner,
        (item) => new Date(item.BehaviourDate).toLocaleDateString(),
        (item) => item.Rating,
        (item) => item.Comment,
        (item) => item.RecordedBy,
      ],
      "No behaviour notes have been recorded yet.",
    );
  } catch (error) {
    showMessage(
      "parentDashboardMessage",
      `Unable to load your child's overview: ${error.message}`,
      "error",
    );
  }
}

async function loadTeacherAttendanceOptions() {
  const learnerSelect = document.getElementById("attendanceLearnerID");
  const behaviourLearnerSelect = document.getElementById("behaviourLearnerID");
  const subjectSelect = document.getElementById("attendanceSubjectID");
  if ((!learnerSelect || !subjectSelect) && !behaviourLearnerSelect) return;

  try {
    const [learnerResult, subjectResult] = await Promise.all([
      api("/learners"),
      api("/subjects"),
    ]);
    const learners = getResultArray(learnerResult, "learners");
    const subjects = getResultArray(subjectResult, "subjects");
    [learnerSelect, behaviourLearnerSelect].filter(Boolean).forEach(function (select) {
      select.replaceChildren(new Option("Select learner", ""));
      learners.forEach(function (learner) {
        select.add(
          new Option(`${learner.FullName} (${learner.Grade})`, learner.LearnerID),
        );
      });
    });
    if (subjectSelect) {
      subjectSelect.replaceChildren(new Option("Class attendance", ""));
      subjects.forEach(function (subject) {
        subjectSelect.add(new Option(subject.SubjectName, subject.SubjectID));
      });
    }

    const dateInput = document.getElementById("attendanceDate");
    if (dateInput && !dateInput.value) {
      const today = new Date();
      today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
      dateInput.value = today.toISOString().slice(0, 10);
    }
  } catch (error) {
    showMessage(
      "teacherAttendanceMessage",
      `Unable to load learners: ${error.message}`,
      "error",
    );
  }
}

async function submitAttendanceEntry(event) {
  if (event) event.preventDefault();
  const learnerId = document.getElementById("attendanceLearnerID")?.value;
  const date = document.getElementById("attendanceDate")?.value;
  const subjectId = document.getElementById("attendanceSubjectID")?.value;
  const status = document.getElementById("attendanceStatus")?.value;
  const comment = document.getElementById("attendanceComment")?.value.trim();

  if (!learnerId || !date || !status) {
    showMessage(
      "teacherAttendanceMessage",
      "Choose a learner, date and attendance status.",
      "error",
    );
    return false;
  }

  try {
    const result = await api("/attendance", {
      method: "POST",
      body: JSON.stringify({
        learnerId: Number(learnerId),
        date,
        subjectId: subjectId ? Number(subjectId) : null,
        status,
        comment,
      }),
    });
    showMessage(
      "teacherAttendanceMessage",
      result.message || "Attendance saved.",
      "success",
    );
    document.getElementById("teacherAttendanceForm")?.reset();
    await loadTeacherAttendanceOptions();
    await displayAttendanceRecords();
  } catch (error) {
    showMessage(
      "teacherAttendanceMessage",
      error.message || "Unable to save attendance.",
      "error",
    );
  }
  return false;
}

async function submitBehaviourRecord(event) {
  if (event) event.preventDefault();
  const learnerID = document.getElementById("behaviourLearnerID")?.value;
  const behaviourDate = document.getElementById("behaviourDate")?.value;
  const rating = document.getElementById("behaviourRating")?.value;
  const comment = document.getElementById("behaviourComment")?.value.trim();
  if (!learnerID || !behaviourDate || !rating || !comment) {
    showMessage("teacherBehaviourMessage", "Complete all behavior note fields.", "error");
    return false;
  }

  try {
    const result = await api("/behaviour", {
      method: "POST",
      body: JSON.stringify({
        learnerID: Number(learnerID),
        behaviourDate,
        rating,
        comment,
      }),
    });
    document.getElementById("teacherBehaviourForm")?.reset();
    showMessage(
      "teacherBehaviourMessage",
      result.message || "Behavior note saved.",
      "success",
    );
    await loadTeacherAttendanceOptions();
  } catch (error) {
    showMessage(
      "teacherBehaviourMessage",
      error.message || "Unable to save behavior note.",
      "error",
    );
  }
  return false;
}

async function displayAttendanceRecords() {
  const adminBody = document.getElementById("adminAttendanceTableBody");
  const parentBody = document.getElementById("parentAttendanceTableBody");
  const teacherBody = document.getElementById("teacherAttendanceTableBody");
  const tableBody = adminBody || parentBody || teacherBody;
  if (!tableBody) return;

  const isParent = Boolean(parentBody);
  const columnCount = isParent ? 5 : 6;
  try {
    const result = await api("/attendance");
    const attendance = getResultArray(result, "attendance");
    tableBody.replaceChildren();
    if (!attendance.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = columnCount;
      cell.textContent = "No attendance records yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    attendance.forEach(function (record) {
      const values = isParent
        ? [record.AttendanceDate, record.Learner, record.Subject || "Class attendance", record.Status || record.AttendanceStatus, record.Comment || "—"]
        : [record.Learner, record.AttendanceDate, record.ClassName, record.Subject || "Class attendance", record.Status || record.AttendanceStatus, record.Comment || "—"];
      const row = document.createElement("tr");
      values.forEach(function (value) {
        const cell = document.createElement("td");
        const dateValue = value === record.AttendanceDate && value
          ? new Date(value).toLocaleDateString()
          : value;
        cell.textContent = dateValue || "—";
        row.appendChild(cell);
      });
      tableBody.appendChild(row);
    });
  } catch (error) {
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = columnCount;
    cell.textContent = `Unable to load attendance: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}
// ======================================================
// 23. ENTER RESULT
// ======================================================
async function enterResult(event) {
  if (event) {
    event.preventDefault();
  }
  const learnerID = document.getElementById("learnerID")?.value;
  const subjectID = document.getElementById("subjectID")?.value;
  const classID = document.getElementById("classID")?.value;
  const term = document.getElementById("term")?.value;
  const mark = document.getElementById("mark")?.value;
  const comment = document.getElementById("comment")?.value.trim();
  if (!learnerID || !subjectID || !term || !mark) {
    alert("Please complete all required result fields.");
    return false;
  }
  try {
    const result = await api("/results", {
      method: "POST",
      body: JSON.stringify({
        learnerID: Number(learnerID),
        subjectID: Number(subjectID),
        classID: classID ? Number(classID) : null,
        term: term,
        mark: Number(mark),
        comment: comment,
      }),
    });
    alert(result.message || "Result entered successfully.");
  } catch (error) {
    console.error("Enter result error:", error);
    alert(error.message || "Unable to enter result.");
  }
  return false;
}
// ======================================================
// TIMETABLE
// ======================================================
async function initializeAdminTimetable() {
  const gradeSelect = document.getElementById("timetableGrade");
  const classSelect = document.getElementById("timetableClassID");
  const subjectSelect = document.getElementById("timetableSubjectID");
  const teacherSelect = document.getElementById("timetableTeacherID");

  try {
    const [classResult, subjectResult, teacherResult, assignmentResult] = await Promise.all([
      api("/classes"),
      api("/subjects"),
      api("/teachers"),
      api("/teacher-subjects"),
    ]);
    timetableAdminClasses = getResultArray(classResult, "classes");
    const subjects = getResultArray(subjectResult, "subjects");
    timetableAdminTeachers = getResultArray(teacherResult, "teachers").filter(
      (teacher) => teacher.Status === "Active",
    );
    timetableAdminSubjectAssignments = getResultArray(assignmentResult, "assignments");
    const grades = [...new Set(timetableAdminClasses.map((item) => item.Grade))];
    const populateSelect = function (select, placeholder, options) {
      select.replaceChildren(new Option(placeholder, ""));
      options.forEach(function (option) {
        select.add(new Option(option.label, option.value));
      });
    };

    populateSelect(
      gradeSelect,
      "Select grade",
      grades.map((grade) => ({ label: grade, value: grade })),
    );
    populateSelect(
      subjectSelect,
      "Select subject",
      subjects.map((subject) => ({
        label: `${subject.SubjectName} (${subject.SubjectCode})`,
        value: subject.SubjectID,
      })),
    );
    gradeSelect.addEventListener("change", updateTimetableClassOptions);
    classSelect.addEventListener("change", updateTimetableTeacherOptions);
    subjectSelect.addEventListener("change", updateTimetableTeacherOptions);
    updateTimetableClassOptions();
    updateTimetableTeacherOptions();
    await displayTimetable();
  } catch (error) {
    showMessage(
      "timetableFormStatus",
      `Unable to load timetable options: ${error.message}`,
      "error",
    );
  }
}

function updateTimetableClassOptions() {
  const gradeSelect = document.getElementById("timetableGrade");
  const classSelect = document.getElementById("timetableClassID");
  if (!gradeSelect || !classSelect) return;

  const classes = timetableAdminClasses.filter(
    (schoolClass) => schoolClass.Grade === gradeSelect.value,
  );
  classSelect.replaceChildren(new Option("Select class", ""));
  classes.forEach(function (schoolClass) {
    classSelect.add(
      new Option(
        `${schoolClass.ClassName} (${schoolClass.Room || "No room"})`,
        schoolClass.ClassID,
      ),
    );
  });
  classSelect.disabled = classes.length === 0;
  updateTimetableTeacherOptions();
}

function updateTimetableTeacherOptions() {
  const classSelect = document.getElementById("timetableClassID");
  const subjectSelect = document.getElementById("timetableSubjectID");
  const teacherSelect = document.getElementById("timetableTeacherID");
  if (!classSelect || !subjectSelect || !teacherSelect) return;

  const classID = Number(classSelect.value);
  const subjectID = Number(subjectSelect.value);
  const schoolClass = timetableAdminClasses.find(
    (item) => Number(item.ClassID) === classID,
  );
  teacherSelect.replaceChildren(new Option("Select teacher", ""));
  if (!schoolClass || !subjectID) {
    teacherSelect.disabled = true;
    return;
  }

  const eligibleTeacherIDs = new Set(
    timetableAdminSubjectAssignments
      .filter(
        (assignment) =>
          Number(assignment.SubjectID) === subjectID &&
          (assignment.ClassID == null || Number(assignment.ClassID) === classID),
      )
      .map((assignment) => Number(assignment.TeacherID)),
  );
  if (schoolClass.ClassTeacherID != null) {
    eligibleTeacherIDs.add(Number(schoolClass.ClassTeacherID));
  }

  const eligibleTeachers = timetableAdminTeachers.filter((teacher) =>
    eligibleTeacherIDs.has(Number(teacher.UserID)),
  );
  if (!eligibleTeachers.length) {
    teacherSelect.replaceChildren(
      new Option("No teacher assigned to this class and subject", ""),
    );
    teacherSelect.disabled = true;
    return;
  }

  eligibleTeachers.forEach(function (teacher) {
    teacherSelect.add(
      new Option(`${teacher.FullName} (${teacher.SystemUserID})`, teacher.UserID),
    );
  });
  teacherSelect.disabled = false;
}

async function displayTimetable() {
  const adminBody = document.getElementById("timetableBody");
  const teacherBody = document.getElementById("teacherTimetableBody");
  const parentBody = document.getElementById("parentTimetableBody");
  const tableBody = adminBody || teacherBody || parentBody;
  if (!tableBody) return;

  const isAdmin = Boolean(adminBody);
  const isParent = Boolean(parentBody);
  const columnCount = isAdmin ? 8 : 7;
  tableBody.replaceChildren();

  try {
    const result = await api("/timetable");
    const entries = getResultArray(result, "timetable");
    if (!entries.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = columnCount;
      cell.textContent = "No timetable entries yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    entries.forEach(function (entry) {
      const row = document.createElement("tr");
      const values = isAdmin
        ? [entry.Grade, entry.ClassName, entry.DayName, entry.StartTime, entry.SubjectName, entry.TeacherName, entry.Room || "—"]
        : isParent
          ? [entry.DayName, entry.StartTime, entry.Grade, entry.ClassName, entry.SubjectName, entry.TeacherName, entry.Room || "—"]
          : [entry.DayName, entry.StartTime, entry.Grade, entry.ClassName, entry.SubjectName, entry.TeacherName, entry.Room || "—"];

      values.forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value || "—";
        row.appendChild(cell);
      });

      if (isAdmin) {
        const actionCell = document.createElement("td");
        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", function () {
          deleteTimetableEntry(entry.TimetableID);
        });
        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);
      }

      tableBody.appendChild(row);
    });
  } catch (error) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = columnCount;
    cell.textContent = `Unable to load timetable: ${error.message}`;
    row.appendChild(cell);
    tableBody.replaceChildren(row);
  }
}

async function submitTimetableEntry(event) {
  if (event) event.preventDefault();

  const classID = document.getElementById("timetableClassID")?.value;
  const subjectID = document.getElementById("timetableSubjectID")?.value;
  const teacherID = document.getElementById("timetableTeacherID")?.value;
  const dayName = document.getElementById("timetableDay")?.value;
  const startTime = document.getElementById("timetableStartTime")?.value;
  const room = document.getElementById("timetableRoom")?.value.trim();

  if (!classID || !subjectID || !teacherID || !dayName || !startTime) {
    showMessage("timetableFormStatus", "Complete all required timetable fields.", "error");
    return false;
  }

  try {
    const result = await api("/timetable", {
      method: "POST",
      body: JSON.stringify({
        classID: Number(classID),
        subjectID: Number(subjectID),
        teacherID: Number(teacherID),
        dayName,
        startTime,
        room,
      }),
    });
    document.getElementById("adminTimetableForm")?.reset();
    updateTimetableClassOptions();
    showMessage(
      "timetableFormStatus",
      result.message || "Timetable entry created.",
      "success",
    );
    await displayTimetable();
  } catch (error) {
    showMessage(
      "timetableFormStatus",
      error.message || "Unable to create timetable entry.",
      "error",
    );
  }

  return false;
}

async function deleteTimetableEntry(timetableID) {
  if (!confirm("Delete this timetable entry?")) return;
  try {
    const result = await api(`/timetable/${timetableID}`, { method: "DELETE" });
    showMessage(
      "timetableFormStatus",
      result.message || "Timetable entry deleted.",
      "success",
    );
    await displayTimetable();
  } catch (error) {
    showMessage(
      "timetableFormStatus",
      error.message || "Unable to delete timetable entry.",
      "error",
    );
  }
}

// ======================================================
// 24. DISPLAY ANNOUNCEMENTS
// ======================================================
async function displayAnnouncements() {
  const tableBody =
    document.getElementById("announcementsTableBody") ||
    document.getElementById("tableBody");

  if (!tableBody) return;

  try {
    const result = await api("/announcements");
    const announcements = getResultArray(result, "announcements");
    tableBody.replaceChildren();

    if (announcements.length === 0) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 5;
      cell.textContent = "No announcements yet.";
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    announcements.forEach(function (announcement) {
      const row = document.createElement("tr");
      const publishedAt =
        announcement.PublishedAt || announcement.publishedAt || "";
      const values = [
        announcement.Title || announcement.title || "",
        announcement.Audience || announcement.audience || "",
        announcement.Category || announcement.category || "",
        announcement.Message || announcement.message || "",
        publishedAt ? new Date(publishedAt).toLocaleString() : "",
      ];

      values.forEach(function (value) {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });

      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Display announcements error:", error);
    tableBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.textContent = `Unable to load announcements: ${error.message}`;
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

async function submitAnnouncement(event) {
  if (event) event.preventDefault();

  const title = document.getElementById("announcementTitle")?.value.trim();
  const audience = document.getElementById("announcementAudience")?.value;
  const category = document.getElementById("announcementCategory")?.value;
  const message = document.getElementById("announcementText")?.value.trim();

  if (!title || !audience || !category || !message) {
    showMessage(
      "announcementMessage",
      "Complete all announcement fields before publishing.",
      "error",
    );
    return false;
  }

  try {
    const result = await api("/announcements", {
      method: "POST",
      body: JSON.stringify({ title, audience, category, message }),
    });
    document.getElementById("announcementForm")?.reset();
    showMessage(
      "announcementMessage",
      result.message || "Announcement published.",
      "success",
    );
    await displayAnnouncements();
  } catch (error) {
    showMessage(
      "announcementMessage",
      error.message || "Unable to publish announcement.",
      "error",
    );
  }

  return false;
}
// ======================================================
// 25. UPDATE DASHBOARD STATISTICS
// ======================================================
async function updateDashboardStats() {
  try {
    const result = await api("/dashboard/stats");
    console.log("Dashboard statistics:", result);
    const stats = result.stats || result.data || result;
    const totalUsers = stats.totalUsers ?? stats.TotalUsers ?? 0;
    const totalLearners = stats.totalLearners ?? stats.TotalLearners ?? 0;
    const totalTeachers = stats.totalTeachers ?? stats.TotalTeachers ?? 0;
    const pendingApplications =
      stats.pendingApplications ?? stats.PendingApplications ?? 0;
    const usersElement = document.getElementById("totalUsers");
    const learnersElement = document.getElementById("totalLearners");
    const teachersElement = document.getElementById("totalTeachers");
    const applicationsElement = document.getElementById("pendingApplications");
    if (usersElement) {
      usersElement.textContent = totalUsers;
    }
    if (learnersElement) {
      learnersElement.textContent = totalLearners;
    }
    if (teachersElement) {
      teachersElement.textContent = totalTeachers;
    }
    if (applicationsElement) {
      applicationsElement.textContent = pendingApplications;
    }
  } catch (error) {
    console.error("Dashboard statistics error:", error);
  }
}
// ======================================================
// 26. UPDATE WELCOME MESSAGE
// ======================================================
function updateWelcomeMessage() {
  const user = getLoggedInUser();
  const welcome = document.getElementById("adminWelcome");
  if (user && welcome) {
    welcome.textContent = "Welcome, " + user.fullName;
  }
}
// ======================================================
// 27. LOGOUT BUTTON
// ======================================================
function setupLogoutButton() {
  const logoutButtons = document.querySelectorAll('[href="login.html"]');
  logoutButtons.forEach(function (button) {
    button.addEventListener("click", function (event) {
      event.preventDefault();
      logout();
    });
  });
}
// ======================================================
// 28. PAGE STARTUP
// ======================================================
document.addEventListener("DOMContentLoaded", function () {
  console.log("High School System JavaScript loaded.");
  if (
    document.getElementById("parentDashboard") &&
    !requireRole("Parent")
  ) {
    return;
  }
  // Dashboard statistics

  if (document.getElementById("parentsTableBody")) {
    displayParents();
  }
  if (
    document.getElementById("totalUsers") ||
    document.getElementById("totalLearners") ||
    document.getElementById("totalTeachers")
  ) {
    updateDashboardStats();
  }
  // Welcome message
  updateWelcomeMessage();
  if (document.getElementById("parentDashboard")) {
    loadParentDashboard();
  }
  // Users page
  if (
    document.getElementById("usersTableBody") ||
    document.getElementById("userTableBody")
  ) {
    displayUsers();
  }
  // Applications page
  if (document.getElementById("applicationsTableBody")) {
    displayApplications();
  }
  // Learners page
  if (document.getElementById("learnersTableBody")) {
    displayLearners();
  }
  // Teachers page
  if (document.getElementById("teachersTableBody")) {
    displayTeachers();
  }
  // Subjects page
  if (document.getElementById("subjectsTableBody")) {
    displaySubjects();
  }
  if (document.getElementById("teacherSubjectAssignmentsTableBody")) {
    displaySubjects();
  }
  if (document.getElementById("teacherClassesTableBody")) {
    displayTeacherClasses();
  }
  if (document.getElementById("teacherSubjectsTableBody")) {
    displayTeacherSubjects();
  }
  // Classes page
  if (document.getElementById("classesTableBody")) {
    displayClasses();
  }
  // Results page
  if (document.getElementById("resultsTableBody")) {
    displayResults();
  }
  if (document.getElementById("reportLearnerID")) {
    initializeLearnerReportBuilder();
  }
  if (document.getElementById("teacherAttendanceForm")) {
    loadTeacherAttendanceOptions();
  }
  if (
    document.getElementById("adminAttendanceTableBody") ||
    document.getElementById("parentAttendanceTableBody") ||
    document.getElementById("teacherAttendanceTableBody")
  ) {
    displayAttendanceRecords();
  }
  // Announcements
  if (document.getElementById("announcementsTableBody")) {
    displayAnnouncements();
  }
  if (
    document.getElementById("parentMessageContacts") ||
    document.getElementById("teacherMessageContacts")
  ) {
    loadMessageContacts();
  }
  if (document.getElementById("adminTimetableForm")) {
    initializeAdminTimetable();
  } else if (
    document.getElementById("teacherTimetableBody") ||
    document.getElementById("parentTimetableBody")
  ) {
    displayTimetable();
  }
  setupLogoutButton();
});
// ======================================================
// 29. MAKE FUNCTIONS AVAILABLE TO HTML onclick=""
// ======================================================
window.doLogin = doLogin;
window.logout = logout;
window.requireLogin = requireLogin;
window.requireRole = requireRole;
window.addUser = addUser;
window.displayUsers = displayUsers;
window.deleteUser = deleteUser;
window.submitApplication = submitApplication;
window.displayApplications = displayApplications;
window.viewApplication = viewApplication;
window.approveApplication = approveApplication;
window.rejectApplication = rejectApplication;
window.displayLearners = displayLearners;
window.displayTeachers = displayTeachers;
window.displaySubjects = displaySubjects;
window.assignTeacherSubject = assignTeacherSubject;
window.displayTeacherClasses = displayTeacherClasses;
window.displayTeacherSubjects = displayTeacherSubjects;
window.displayClasses = displayClasses;
window.displayResults = displayResults;
window.initializeLearnerReportBuilder = initializeLearnerReportBuilder;
window.generateLearnerReport = generateLearnerReport;
window.loadParentResults = loadParentResults;
window.loadTeacherAttendanceOptions = loadTeacherAttendanceOptions;
window.submitAttendanceEntry = submitAttendanceEntry;
window.displayAttendanceRecords = displayAttendanceRecords;
window.loadParentDashboard = loadParentDashboard;
window.submitBehaviourRecord = submitBehaviourRecord;
window.enterResult = enterResult;
window.displayAnnouncements = displayAnnouncements;
window.loadMessageContacts = loadMessageContacts;
window.openMessageConversation = openMessageConversation;
window.sendSchoolMessage = sendSchoolMessage;
window.displayTimetable = displayTimetable;
window.submitTimetableEntry = submitTimetableEntry;
window.deleteTimetableEntry = deleteTimetableEntry;
window.updateDashboardStats = updateDashboardStats;
window.viewLearner = viewLearner;
window.closeLearnerDetails = closeLearnerDetails;
window.displayTeachers = displayTeachers;
window.displayParents = displayParents;
window.displayClasses = displayClasses;
window.assignClassTeacher = assignClassTeacher;
window.assignLearnerToClass = assignLearnerToClass;
